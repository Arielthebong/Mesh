//
//  ViewController.swift
//  MeshSettings
//
//  Created by Akash Wadawadigi on 8/15/16.
//  Copyright © 2016 Stanford University. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var settingsOptions: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        settingsOptions.dataSource = self
        settingsOptions.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //Only need 1 section
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    //Array of Titles for cells in settings tab
    var settingsOpts = ["Account Settings", "Change Account Email", "Add Secondary Email", "Change Password", "Verify Student Email", "Advanced", "Notification Settings", "Location Settings", "Information", "Support", "Terms of Service", "Privacy Policy", "Licenses", "Logout"]
    

    func tableView(tableView: UITableView,
                   cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell:UITableViewCell = UITableViewCell(style:UITableViewCellStyle.Value1, reuseIdentifier:"SettingOpt")
        
        let isSectionHeader = indexPath.row
        
        //We want the headers to be in red and the subheaders to be in grey
        if(isSectionHeader == 0 || isSectionHeader == 5 || isSectionHeader == 8 || isSectionHeader == 13){
            cell.backgroundColor = UIColor(red: 248/255, green: 40/255, blue: 54/255, alpha: 0.85)
            cell.textLabel?.textColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        } else {
            cell.backgroundColor = UIColor(red: 147/255, green: 149/255, blue: 152/255, alpha: 0.35)
        }
  
        //Populating text fields
        cell.textLabel?.text = settingsOpts[indexPath.row]
        cell.textLabel?.font = UIFont(name: "Calibri Light", size: 17)
        //Need to change the font
        
        return cell
    }
    
    //sets number of rows in sections
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsOpts.count
    }
    
    //Will be used when we link each cell to its own screen
    /*func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        NSLog("You selected cell number: \(indexPath.row)!")
        self.performSegueWithIdentifier("yourIdentifier", sender: self)
    }*/


}

