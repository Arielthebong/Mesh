//
//  eventList.swift
//  calendarUpdates
//
//  Created by Ariel Bong on 7/25/16.
//  Copyright © 2016 ArielBong. All rights reserved.
//

import Foundation
import UIKit

class eventList {
    /*class var sharedInstance: eventList {
        struct Static {
           // private init(){}
            static let instance = eventList()
        }
       
        guard let instance = Static.instance else {
            fatalError("Unable to obtain reference to eventList singleton instance.")
        }
        
        return instance
    }
    
    
    
    
    func addEvent(newEvent: event, orderedArray: orderedEventArray) {
    // persist a representation of this todo item in NSUserDefaults; have to do this in order for the local notification to stay after app is closed 
    var eventDictionary = NSUserDefaults.standardUserDefaults().dictionaryForKey(EVENTS_KEY) ?? Dictionary() // if todoItems hasn't been set in user defaults, initialize todoDictionary to an empty dictionary using nil-coalescing operator (??)
    eventDictionary[newEvent.getUUID()] = ["eventTime": newEvent.getEventDayWithTime(), "title": newEvent.getTitle(), "UUID": newEvent.getUUID()] // store NSData representation of todo item in dictionary with UUID as key
    NSUserDefaults.standardUserDefaults().setObject(eventDictionary, forKey: EVENTS_KEY) // save/overwrite todo item list
        
        
    // create a corresponding local notification
    let notification = UILocalNotification()
    notification.alertBody = "Mesh Event: \"\(newEvent.getTitle())\" " // text that will be displayed in the notification
    notification.alertAction = "open" // text that is displayed after "slide to..." on the lock screen - defaults to "slide to view"
    notification.fireDate = newEvent.getEventDayWithTime()// event time (when notification will be fired)
    notification.soundName = UILocalNotificationDefaultSoundName // play default sound
    notification.userInfo = ["title": newEvent.getTitle(), "UUID": newEvent.getUUID()] // assign a unique identifier to the notification so that we can retrieve it later
        
    UIApplication.sharedApplication().scheduleLocalNotification(notification)
        
    orderedArray.addEvent(newEvent)
    
    }
    */
 
}

