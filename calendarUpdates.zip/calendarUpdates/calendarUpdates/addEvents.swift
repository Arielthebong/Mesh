//
//  addEvents.swift
//  calendarUpdates
//
//  Created by Ariel Bong on 7/25/16.
//  Copyright © 2016 ArielBong. All rights reserved.
//

import UIKit

class addEvents: UIViewController{

    @IBOutlet weak var eventTextField: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var saveButton: UIButton!
    
    var startingDate: NSDate?
    

    override func viewDidLoad() {
        super.viewDidLoad()
        datePicker.setDate(startingDate!, animated: false)
        
        //Looks for single or multiple taps. Closes keyboard when clicks screen
        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(addEvents.dismissKeyboard))
        view.addGestureRecognizer(tap)

        // Do any additional setup after loading the view.
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func savePressed(sender: AnyObject) {
        let newEvent = event(time: datePicker.date, title: eventTextField.text!, meetingWith: "", UUID: NSUUID().UUIDString)
        print(newEvent.getTitle())
        print(newEvent.getUUID())
        
        orderedEventArray.sharedList.addEvent(newEvent)
        self.navigationController?.popToRootViewControllerAnimated(true) 
    }
    
   
   
    
    
    

}
