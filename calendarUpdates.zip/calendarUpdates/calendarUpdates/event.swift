//
//  event.swift
//  calendarUpdates
//
//  Created by Ariel Bong on 7/25/16.
//  Copyright © 2016 ArielBong. All rights reserved.
//

import Foundation

struct event {
    private var title: String?
    private var eventDayWithTime: NSDate
    private var meetingWith: String
    private var UUID: String
    
    init(time: NSDate, title: String, meetingWith: String, UUID: String) {
        self.title = title
        eventDayWithTime = time
        self.meetingWith = meetingWith
        self.UUID = UUID
    }
    
    func getTitle() -> String {
        if title == nil {
            return " "
        }
        return title!
    }
    
  
    func getEventDayWithTime() -> NSDate {
        return eventDayWithTime
    }
    
    func getEventDay() -> NSDate {
        return NSCalendar.currentCalendar().startOfDayForDate(eventDayWithTime)
    }
    
    func getUUID() -> String {
        return UUID
    }

}
