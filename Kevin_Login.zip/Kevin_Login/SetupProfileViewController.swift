//
//  SetupProfileViewController.swift
//  Mesh
//
//  Created by Kevin Kusch on 8/23/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import UIKit

class SetupProfileViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var schoolTextField: UITextField!
    @IBOutlet weak var schoolEmailTextField: UITextField!
    @IBOutlet weak var companyTextField: UITextField!
    var school: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        schoolTextField.delegate = self
        self.schoolTextField.text = self.school
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func setupProfile(sender: UIButton) {
        if firstNameTextField.text!.isEmpty {
            displayAlert("Enter first name")
        } else if lastNameTextField.text!.isEmpty {
            displayAlert("Enter last name")
        }
        
        let profile = User()
        profile.setFirstName(firstNameTextField.text!)
        profile.setLastName(lastNameTextField.text!)
        profile.setSchool(schoolTextField.text!)
        profile.setCompany(companyTextField.text!)
        profile.setSecondaryEmail(schoolEmailTextField.text!)
        saveProfile(profile)
        
        self.performSegueWithIdentifier("network", sender: self)
        
        
        // Add check that student email is valid/ends in edu?
        
    }
    
    func displayAlert(alertMessage: String) {
        let alertController = UIAlertController(title: "Error", message:
            alertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        self.performSegueWithIdentifier("setupToSchoolTable", sender: self)
        return false
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
