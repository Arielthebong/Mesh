//
//  ViewController.swift
//  Mesh
//
//  Created by Kevin Kusch on 7/24/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import UIKit
import Firebase

class LogInViewController: UIViewController {

    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    var masteraccounts: [String:String]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func login(sender: UIButton) {
        if EmailTextField.text!.isEmpty {
            displayAlert("Please enter your email address")
        } else if PasswordTextField.text!.isEmpty {
            displayAlert("Please enter your password")
        }
        
        if let email = EmailTextField.text, password = PasswordTextField.text {
            FIRAuth.auth()?.signInWithEmail(email, password: password) { (user, error) in
                if let error = error {
                    self.displayAlert(error.localizedDescription)
                }
                isTechAccount() {(isTechAccount) in
                    getMasterAccountRequests() { masterAccounts in
                        self.masteraccounts = masterAccounts
                        self.segueToCorrectScreen(isTechAccount)
                    }
                    
                }
            }
        }
    }
    
    func displayAlert(alertMessage: String) {
        let alertController = UIAlertController(title: "Error", message:
            alertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    func segueToCorrectScreen(isTechAccount: Bool) {
        if(isTechAccount) {
            self.performSegueWithIdentifier("requestTable", sender: self)
        } else {
            self.performSegueWithIdentifier("login", sender: self)
            
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "requestTable") {
            let masterRequestVC = segue.destinationViewController as? MasterRequestTable
            masterRequestVC?.masterAccountRequests = masteraccounts
            masterRequestVC?.masterAccountRequestKeys = Array(masteraccounts!.keys)
        }
    }

}

