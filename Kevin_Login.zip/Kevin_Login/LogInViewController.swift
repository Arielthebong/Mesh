//
//  ViewController.swift
//  Mesh
//
//  Created by Kevin Kusch on 7/24/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import UIKit
import Firebase

class LogInViewController: UIViewController {

    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    var masteraccounts: [String:String]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        view.addGestureRecognizer(tap)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    @IBAction func login(sender: UIButton) {
        if EmailTextField.text!.isEmpty {
            displayAlert("Please enter your email address")
        } else if PasswordTextField.text!.isEmpty {
            displayAlert("Please enter your password")
        } else if let email = EmailTextField.text, password = PasswordTextField.text {
            FIRAuth.auth()?.signInWithEmail(email, password: password) { (user, error) in
                if error != nil {
                    self.displayAlert(error!.localizedDescription)
                } else {
                    self.performSegueWithIdentifier("myNetwork", sender: self)
                }
            }
        }
    }
    
    func displayAlert(alertMessage: String) {
        let alertController = UIAlertController(title: "Error", message:
            alertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
}

