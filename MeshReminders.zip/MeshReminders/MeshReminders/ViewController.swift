//
//  ViewController.swift
//  MeshReminders
//
//  Created by Akash Wadawadigi on 8/27/16.
//  Copyright © 2016 Stanford University. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var reminderTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Setting background color
        self.view.backgroundColor = UIColor(red: 248/255, green: 40/255, blue: 54/255, alpha: 0.85)
        
        reminderTable.dataSource = self
        reminderTable.delegate = self
        
        reminderTable.tableFooterView = UIView()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    //set number of sections
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    //sets number of rows in sections
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1//array of reminders.count
    }
    
    
    //sets all the rows to the names of the array (nearbyUserNames)
    func tableView(tableView: UITableView,
                   cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cell: reminderCell! = reminderTable.dequeueReusableCellWithIdentifier("ReminderCell") as? reminderCell
        
        //Access the elements of the array that holds the contact name
        //cell.contactName.text = ""
        
        //Access the element of the array that holds the contact's affiliation
        //cell.reminderAffiliation.text = ""
        
        //Access the element of the array that holds the date of meeting
        //cell.reminderDate.text = ""
        
        //Access the element of the array that holds the time of the meeting
        //cell.reminderTime.text = ""
        
        return cell
    }

    //Function that segues to screen with the reminder settings
    @IBAction func reminderSettingsCalled(sender: AnyObject) {
        print("Hello")
    }
}



