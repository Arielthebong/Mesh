//
//  NewsFeed.swift
//  Mesh
//
//  Created by Daniel Ssemanda on 8/4/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import UIKit
import AVFoundation

let cellId = "cellId"
var navigationLogoImage = UIImage(named:"mesh logo login")!
//let navBar: UINavigationItem = UINavigationItem()
var masterNavBar = UIView()
var posts: [Post] = []
var secondBar = UIView()
let searchBox = TextField()
var cornerQuickAccessButton = UIButton()
var lastScrollOffset: CGFloat = 0

var reminderNumberOfNotifications = 999
var contactNumberOfNotifications = 999
var bigRedMenu = UIView()
let bigRedCollectionView = BigRedCollectionView(collectionViewLayout: UICollectionViewFlowLayout())

//Stuff for Corner Menu
var cornerMenuBool = false
var dimming = UIView()
var addContactLabelPic = UIButton()
var addNearbyContactLabelPic = UIButton()
var addNearbyContactIcon = UIButton()
var scanQRCodeLabelPic = UIButton()
var scanQRCodeIcon = UIButton()
var myQRCodeLabelPic = UIButton()
var myQRCodeIcon = UIButton()


class Post{
    var name: String?
    var statusText: String?
    var profilePic: UIImage?
}


class FeedController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    let customCellIdentifier = "customCellIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let frame = self.view.frame
        secondBar = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y + 66, view.frame.width, 36))
//        self.navigationController?.navigationBarHidden = true
        
        
//        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
//        swipeUp.direction = UISwipeGestureRecognizerDirection.Up
        
        //Deals with tapping collectionview and navbar when stuff is open
        thingsToDoWhenNavBarOrCollectionViewTapped()
        
        //Manually constructing posts
        customCreatedPosts()
        
        //Creating the a second NavBar to store search button
        createSecondNavBar()
        
        //navigationItem.title = ""
        
        //removes atomatic space for navbar inherent within collection view
        self.automaticallyAdjustsScrollViewInsets = false
        
        //Creates the top NavBar Buttons
        createAndAddButtonsToNavBar()
        
        //Makes bottom right corner button
        createCornerButton()
       
//        let myQRCodeImage = UIImageView(image:  UIImage(named: "icon qr bubble"))
//        let scanQRCodeLabel = UIImageView(image:  UIImage(named: "scan qr bubble text"))
        
        //Quick NavBar Setup stuff
        collectionView?.alwaysBounceVertical = true //Nice bounce effect when scrolling
        collectionView?.backgroundColor = UIColor.whiteColor()
        collectionView?.registerClass(FeedCell.self, forCellWithReuseIdentifier: cellId)
        
    }
    
    //Manually constructing posts
    func customCreatedPosts(){
        let postDan = Post()
        postDan.name = "The Boston Consulting Group"
        postDan.statusText = "Booth Will be Open at Yale Career Fair"
        postDan.profilePic = UIImage(named: "bcg_Logo")
        
        let postMawi = Post()
        postMawi.name = "Omar Zaki"
        postMawi.statusText = "Don't ever play yourself"
        postMawi.profilePic = UIImage(named: "Hillary")
        
        //Adding manually constructed posts to Array
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postMawi)
        posts.append(postMawi)
        posts.append(postMawi)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
    }
    
    
    //Setting where the collectionView will be located and its size
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        let frame = self.view.frame
        self.collectionView!.frame = CGRectMake(frame.origin.x, frame.origin.y + 66, frame.size.width, frame.size.height - 66)
    }
    
    //How many total cells will be displayed
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return posts.count
    }
    
    //Things that are true for all cells
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        //Stuff that is true for all cells
        let feedCell =  collectionView.dequeueReusableCellWithReuseIdentifier(cellId, forIndexPath: indexPath) as! FeedCell
        feedCell.contentView.backgroundColor = UIColor.rgb(230, green: 231, blue: 232) //cell background color
        
        feedCell.post = posts[indexPath.item]
        return feedCell
    }
    
    //Sets the cize of each cell
    func collectionView(collectionView: UICollectionView, layout collectViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        
        if let statusText = posts[indexPath.item].statusText {
            
            let heightOfText = statusText.heightWithConstrainedWidth(286, font: UIFont(name: "Calibri-Light", size: 11)!)
            
            if heightOfText <= 22 {
                //print("The given height of this cell is 60")
                return CGSizeMake(view.frame.width, 60)
            }
            else {
                let numberOfLines = heightOfText/11
                    
                let changingNum = (numberOfLines - 2) * 3
                let adjustment = heightOfText - (22 - changingNum)
                //print("This is the changingNum used for the number below: \(changingNum)")
                //print("The given height of this cell is \(60 + adjustment)")
                return CGSizeMake(view.frame.width, 60 + adjustment)
            }
            
            
        }
        
        return CGSizeMake(view.frame.width, 60) //height of each cell
    }
    
    //Sets the distance between cells and the top of the view
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
    let frame : CGRect = self.view.frame
    let margin  = (frame.width - 90 * 3) / 6.0
    return UIEdgeInsetsMake(36, margin, 10, margin)  //First number sets distance from the top
    
    }
    
    //Function to handle the effects of screen rotation
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransitionToSize(size, withTransitionCoordinator: coordinator)
        
        collectionView?.collectionViewLayout.invalidateLayout()
    }

    //Deals with tapping outside of keyboard and brings newsfeed to top when NavBar double tapped
    func thingsToDoWhenNavBarOrCollectionViewTapped() {
        
        let tappingCollectionView = UITapGestureRecognizer(target: self, action: #selector(removeBigRedMenu2))
        self.collectionView?.addGestureRecognizer(tappingCollectionView)
        
        let tappingNavBar = UITapGestureRecognizer(target: self, action: #selector(removeBigRedMenu2))
        masterNavBar.addGestureRecognizer(tappingNavBar)

        let tappedNavBarTwice = UITapGestureRecognizer(target: self, action: #selector(bringNewsFeedToTop))
        tappedNavBarTwice.numberOfTapsRequired = 2
        masterNavBar.addGestureRecognizer(tappedNavBarTwice)
        
    }
    
    //Keeps track of scrolling up or down and whether at top or bottom
    override func scrollViewDidScroll(scrollView: UIScrollView) {
        let scrollViewHeight = scrollView.frame.size.height;
        let scrollContentSizeHeight = scrollView.contentSize.height;
        let scrollOffset = scrollView.contentOffset.y;
        
        if (lastScrollOffset > scrollOffset && scrollOffset != 0 && (scrollOffset + scrollViewHeight <= scrollContentSizeHeight)){
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                secondBar.alpha = 1
                }, completion: nil)
      
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                cornerQuickAccessButton.alpha = 1
                }, completion: nil)
        }
        else if (lastScrollOffset < scrollOffset && (scrollOffset + scrollViewHeight != scrollContentSizeHeight) && scrollOffset >= 0){
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                secondBar.alpha = 0
                }, completion: nil)
            
        }
        
        lastScrollOffset = scrollOffset
        
        if (scrollOffset == 0)
        {
            print("Im at the top")
            secondBar.alpha = 1
            
            
        }
        else if (scrollOffset + scrollViewHeight == scrollContentSizeHeight)
        {
            print("Im at the bottom!!!")
            secondBar.alpha = 0
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                cornerQuickAccessButton.alpha = 0.2
                }, completion: nil)
        }
        
    }
    
    //Stuff to do before any segue occurrs
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
    }
    
    //Lightening the corner button
//    override func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
//        UIView.animateWithDuration(0.5, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
//            CornerQuickAccessButton.alpha = 1
//            }, completion: nil)
//    }
    
    //Lightening the corner button
//    override func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
//        UIView.animateWithDuration(0.5, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
//            CornerQuickAccessButton.alpha = 1
//            }, completion: nil)
//    }
    
    //Bringing out the Big Red Menu
    func bringOutTheBigRedMenu(){
        let frame = self.view.frame
        
        bigRedMenu = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, ceil(self.view.frame.width * (2/3))  , frame.height))
        bigRedMenu.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        
        let slideInFromLeftTransition = CATransition()
        slideInFromLeftTransition.type = kCATransitionPush
        slideInFromLeftTransition.subtype = kCATransitionFromLeft
        slideInFromLeftTransition.duration = 0.3
        slideInFromLeftTransition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        slideInFromLeftTransition.fillMode = kCAFillModeRemoved
        bigRedMenu.layer.addAnimation(slideInFromLeftTransition, forKey: "slideInFromLeftTransition")
        
        let  whiteCollapseLeft = UIButton(type: .Custom)
        whiteCollapseLeft.setImage(UIImage(named: "icon collapse left white"), forState: .Normal)
        whiteCollapseLeft.addTarget(self , action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        
        let navigationButton = UIButton(type: .Custom)
        navigationButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        let stringFormat = NSMutableAttributedString(string: "Navigation", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 28)!, NSForegroundColorAttributeName: UIColor.whiteColor()])
        navigationButton.setAttributedTitle(stringFormat, forState: .Normal)
        navigationButton.addTarget(self , action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        //        self.navigationController.addChildViewController(bigRedCollectionView) //Seems to be unnecessary
//        bigRedCollectionView.didMoveToParentViewController(masterNavBar)
        
        let settingsButton = UIButton(type: .Custom)
        settingsButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        let stringFormat2 = NSMutableAttributedString(string: "Settings", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 28)!, NSForegroundColorAttributeName: UIColor.whiteColor()])
        settingsButton.setAttributedTitle(stringFormat2, forState: .Normal)
//        settingsButton.addTarget(<#T##target: AnyObject?##AnyObject?#>, action: <#T##Selector#>, forControlEvents: <#T##UIControlEvents#>)
        
        let settingsLogo = UIButton(type: .Custom)
        settingsLogo.setImage(UIImage(named: "icon sidebar settings"), forState: .Normal)
//        settingsLogo.addTarget(<#T##target: AnyObject?##AnyObject?#>, action: <#T##Selector#>, forControlEvents: <#T##UIControlEvents#>)
        
        let whiteLogo = UIButton(type: .Custom)
        whiteLogo.setImage( UIImage(named: "mesh logo small white"), forState: .Normal)
        whiteLogo.addTarget(self, action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        bigRedMenu.addSubview(whiteLogo)
        bigRedMenu.addSubview(whiteCollapseLeft)
        bigRedMenu.addSubview(navigationButton)
        bigRedMenu.addSubview(settingsLogo)
        bigRedMenu.addSubview(settingsButton)
        bigRedMenu.addSubview(bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|-15-[v0(40)][v1(8)]-8-[v2]", views: whiteLogo, whiteCollapseLeft, navigationButton)
        bigRedMenu.addConstraintsWithFormat("V:|-19-[v0(40)]", views: whiteLogo)
        bigRedMenu.addConstraintsWithFormat("V:|-44-[v0(15)]", views: whiteCollapseLeft)
        bigRedMenu.addConstraintsWithFormat("V:|-23-[v0(40)]", views: navigationButton)
        bigRedMenu.addConstraintsWithFormat("V:|-70-[v0]-70-|", views: bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|[v0]|", views: bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|-20-[v0(30)]-8-[v1]", views: settingsLogo, settingsButton)
        bigRedMenu.addConstraintsWithFormat("V:[v0(30)]-15-|", views: settingsLogo)
        bigRedMenu.addConstraintsWithFormat("V:[v0]-10-|", views: settingsButton)
        view.addSubview(bigRedMenu)
        view.bringSubviewToFront(bigRedMenu)
        
        
    }
    
    //When the Big Red Menu needs to go away
    func removeBigRedMenu(){
        let menuWidth = bigRedMenu.bounds.width
        
        let offstageLeft = CGAffineTransformMakeTranslation( -menuWidth, 0)
        UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            bigRedMenu.transform = offstageLeft
            }, completion: {(finished:Bool) in
                    self.finishOffBigRedMenu()
        })
    
    }
    
    func finishOffBigRedMenu() {
       bigRedMenu.removeFromSuperview()
    }
    
    //Difference is this is called when collection view  or navbar is tapped
    func removeBigRedMenu2(gesture: UITapGestureRecognizer){
        let menuWidth = bigRedMenu.bounds.width
        searchBox.resignFirstResponder()
        let offstageLeft = CGAffineTransformMakeTranslation( -menuWidth, 0)
        UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            bigRedMenu.transform = offstageLeft
            }, completion: nil)
    }
    
    //Makes bottom right corner button
    func createCornerButton(){
        cornerQuickAccessButton = UIButton(frame: CGRectMake(view.frame.width - 75, view.frame.height - 75, 65, 65))
        cornerQuickAccessButton.setImage(UIImage(named: "icon contact add"), forState: .Normal)
        cornerQuickAccessButton.addTarget(self, action: #selector(bringCornerMenu), forControlEvents: .TouchUpInside)
        view.addSubview(cornerQuickAccessButton)
        
    }
    
    //When you hit the lower right hand corner button
    func bringCornerMenu() {
        if (!cornerMenuBool){
            cornerMenuBool = true
            let frame = self.view.frame
            dimming = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, view.frame.width, view.frame.height))
            dimming.backgroundColor = UIColor.whiteColor()
            dimming.alpha = 0.5
            
            let slideInFromBottomTransition = CATransition()
            slideInFromBottomTransition.type = kCATransitionPush
            slideInFromBottomTransition.subtype = kCATransitionFromBottom
            slideInFromBottomTransition.duration = 0.3
            slideInFromBottomTransition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
            slideInFromBottomTransition.fillMode = kCAFillModeRemoved
            
            addContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 183, view.frame.height - 53, 103, 25))
            addContactLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            addContactLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            addNearbyContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 113, 103, 25))
            addNearbyContactLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            addNearbyContactLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            addNearbyContactIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 125, 50, 50))
            addNearbyContactIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            addNearbyContactIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            scanQRCodeLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 163, 103, 25))
            scanQRCodeLabelPic.setImage( UIImage(named: "scan qr bubble text"), forState: .Normal)
            scanQRCodeLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            scanQRCodeIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 175, 50, 50))
            scanQRCodeIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            scanQRCodeIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            myQRCodeLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 213, 103, 25))
            myQRCodeLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            myQRCodeLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            myQRCodeIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 225, 50, 50))
            myQRCodeIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            myQRCodeIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            cornerQuickAccessButton.removeFromSuperview()
            view.addSubview(dimming)
            view.addSubview(cornerQuickAccessButton)
            view.addSubview(addContactLabelPic)
            view.addSubview(addNearbyContactLabelPic)
            view.addSubview(addNearbyContactIcon)
            view.addSubview(scanQRCodeLabelPic)
            view.addSubview(scanQRCodeIcon)
            view.addSubview(myQRCodeLabelPic)
            view.addSubview(myQRCodeIcon)
            cornerQuickAccessButton.alpha = 1
            
            
            //
            //            addContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 183, view.frame.height + 1, 103, 25))
            //        UIView.animateWithDuration(0.3, delay: 0.1, options: UIViewAnimationOptions.CurveEaseIn , animations: {
            //            addContactLabelPic = UIButton(frame: CGRectMake(self.view.frame.width - 183, self.view.frame.height - 53, 103, 25))
            //        }, completion: nil)
            //
            
            let tapDimmingView = UITapGestureRecognizer(target: self, action: #selector(removeCornerMenu))
            dimming.addGestureRecognizer(tapDimmingView)
            let tapDimmingView2 = UITapGestureRecognizer(target: self, action: #selector(removeCornerMenu2))
            masterNavBar.addGestureRecognizer(tapDimmingView2)
            //        view.addConstraintsWithFormat("H:|", views: <#T##UIView...##UIView#>)
        }
        
    }
    
    //Used to remove corner menu
    func removeCornerMenu(gesture: UITapGestureRecognizer){
        dimming.removeFromSuperview()
        addContactLabelPic.removeFromSuperview()
        addNearbyContactLabelPic.removeFromSuperview()
        addNearbyContactIcon.removeFromSuperview()
        scanQRCodeLabelPic.removeFromSuperview()
        scanQRCodeIcon.removeFromSuperview()
        myQRCodeLabelPic.removeFromSuperview()
        myQRCodeIcon.removeFromSuperview()
        
        cornerMenuBool = false
    }
    
    //Had to make another just for the NavBar :(
    func removeCornerMenu2(gesture: UITapGestureRecognizer){
        dimming.removeFromSuperview()
        addContactLabelPic.removeFromSuperview()
        
        cornerMenuBool = false
    }
    
    //Creating the a second NavBar to store search button
    func createSecondNavBar() {
//        let frame = self.view.frame
        secondBar.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(secondBar)
        
        let grayBox = UIView()
        grayBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        
        let searchButton = UIButton()
        searchButton.setImage(UIImage(named:"icon search"), forState: .Normal)
//        searchButton.addTarget(self, action: #selector(makeSegueChange), forControlEvents: UIControlEvents.TouchUpInside)
        
        
        searchBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        //      searchBox.backgroundColor = UIColor.rgb(176, green: 238, blue: 237)
        searchBox.layer.borderWidth = 1.0
        searchBox.layer.borderColor = UIColor.blackColor().CGColor
        searchBox.placeholder = "Type a company name"
        //searchBox.font = UIFont(name: "Calibri-Light", size: 11)!
        searchBox.font = UIFont.systemFontOfSize(11)
        searchBox.layer.cornerRadius = 5
        //      searchBox.hidden = false
        searchBox.addTarget(self, action: #selector(touchedSearchBox), forControlEvents: UIControlEvents.EditingDidBegin)
        searchBox.addTarget(self, action: #selector(leftSearchBox), forControlEvents: UIControlEvents.EditingDidEnd)
        
        
        
        //        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(touchedSearchBox))
        //        secondBar.addGestureRecognizer(tapGesture)
        
        let sortBy = UIButton(type: .System)
        let sortByText = NSMutableAttributedString()
        let sortByFirstPart = NSAttributedString(string: "Sort by", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 11)!, NSForegroundColorAttributeName: UIColor.rgb(88, green: 89, blue: 91)])
        let sortBySecondPart = NSAttributedString(string: " new", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 11)!, NSForegroundColorAttributeName: UIColor.rgb(228, green: 40, blue: 54)])
        sortByText.appendAttributedString(sortByFirstPart)
        sortByText.appendAttributedString(sortBySecondPart)
        let dropDownAttachment = NSTextAttachment()
        dropDownAttachment.image = UIImage(named: "icon collapse down")
        dropDownAttachment.bounds = CGRectMake(0,0,8,4)
        sortByText.appendAttributedString(NSAttributedString(attachment: dropDownAttachment))
        sortBy.setAttributedTitle(sortByText, forState: .Normal)
        
        
        secondBar.addSubview(searchBox)
        secondBar.addSubview(grayBox)
        secondBar.addSubview(searchButton)
        secondBar.addSubview(sortBy)
        secondBar.addConstraintsWithFormat("H:[v0(18)]-10-|", views: searchButton)
        secondBar.addConstraintsWithFormat("V:|-9-[v0(17)]", views: searchButton)
        secondBar.addConstraintsWithFormat("V:|-6-[v0(24)]", views: searchBox)
        secondBar.addConstraintsWithFormat("H:|-0-[v0(66)]-0-[v1]-2-[v2(37)]|", views: sortBy, searchBox, grayBox)
        secondBar.addConstraintsWithFormat("V:|-6-[v0(24)]", views: grayBox)
        secondBar.addConstraintsWithFormat("V:|-12-[v0(24)]", views: sortBy)
        
    }
    
    //Creating the NavBar
    func createAndAddButtonsToNavBar() {
        //Creating Buttons to be stored on left and right side of NavBar
        let bounds = UIScreen.mainScreen().bounds
        let width = bounds.size.width
//        let height = bounds.size.height
        
        masterNavBar = UIView(frame: CGRectMake(0, 0, width, 65))
        let grayLine = UIView(frame: CGRectMake(0, 65, width, 1))
        grayLine.backgroundColor = UIColor.lightGrayColor()
        self.view.addSubview(grayLine)
        
        let leftSideView = UIView()
        leftSideView.frame = CGRectMake(0, 0, 55, 80)
//        leftSideView.backgroundColor = UIColor.blueColor()
        
        let logoButton: UIButton = {
            let button = UIButton()
            button.setImage(navigationLogoImage, forState: .Normal)
            button.addTarget(self, action: #selector(bringOutTheBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
            button.frame = CGRectMake(0, 0, 40, 40)
            return button
        }()
        
        let collapseRight = UIImage(named: "icon collapse right")!
        
        let collapseRightButton : UIButton = {
            let button = UIButton()
            button.setImage(collapseRight, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
            button.addTarget(self, action: #selector(bringOutTheBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
            return button
        }()
        
//        let newsFeedBarButton = UIBarButtonItem(title: "News Feed", style: UIBarButtonItemStyle.Plain, target: self, action: nil)
//        newsFeedBarButton.tintColor = UIColor.rgb(228, green: 40, blue: 54)
//        let font = UIFont(name: "Calibri-Light", size: 20)
//        newsFeedBarButton.setTitleTextAttributes([NSFontAttributeName: font!], forState: UIControlState.Normal )
        let barNameLabel = UILabel()
        barNameLabel.text = "News Feed"
        barNameLabel.font = UIFont(name: "Calibri-Light", size: 28)
        barNameLabel.textColor = UIColor.rgb(228, green: 40, blue: 54)
        
        leftSideView.addSubview(logoButton)
        leftSideView.addSubview(collapseRightButton)
        leftSideView.addSubview(barNameLabel)
        leftSideView.addConstraintsWithFormat("H:|[v0(40)]-0-[v1(8)]-7-[v2]", views: logoButton, collapseRightButton, barNameLabel)
        leftSideView.addConstraintsWithFormat("V:|-19-[v0(40)]", views: logoButton)
        leftSideView.addConstraintsWithFormat("V:|-44-[v0(15)]", views: collapseRightButton)
        leftSideView.addConstraintsWithFormat("V:|-28-[v0]", views: barNameLabel)
        
//        let leftSideButtons = UIBarButtonItem(customView: leftSideView)
        
        
        masterNavBar.addSubview(leftSideView)
        
//        navigationItem.leftBarButtonItems = [ leftSideButtons, newsFeedBarButton]
        
        
        
        let rightSideView = UIView()
        rightSideView.frame = CGRectMake(0, 0, 100, 80)
        
        
        let reminderButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(named:"icon reminder")!, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
//            button.addTarget(self, action: #selector(reminderButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
            return button
        }()
        
        let contactButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(named:"icon contact")!, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
            //button.addTarget(<#T##target: AnyObject?##AnyObject?#>, action: <#T##Selector#>, forControlEvents: <#T##UIControlEvents#>)
            return button
        }()
        
        let contactNumberBubble = UIImageView(image: UIImage(named: "icon number bubble"))
        
        
        
        let reminderNumberBubble = UIView()
        reminderNumberBubble.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        
        
//        rightSideView.backgroundColor = UIColor.blueColor()
        
        let contactNotificationsLabel = UILabel()
        contactNotificationsLabel.text = "\(contactNumberOfNotifications)"
        contactNotificationsLabel.textColor = UIColor.whiteColor()
        contactNotificationsLabel.font = UIFont.boldSystemFontOfSize(10)
        
        let reminderNotificationsLabel = UILabel()
        reminderNotificationsLabel.text = "\(reminderNumberOfNotifications)"
        reminderNotificationsLabel.textColor = UIColor.whiteColor()
        reminderNotificationsLabel.font = UIFont.boldSystemFontOfSize(10)
        
        rightSideView.addSubview(reminderButton)
        rightSideView.addSubview(contactButton)
        rightSideView.addSubview(contactNumberBubble)
        rightSideView.addSubview(contactNotificationsLabel)
        rightSideView.addSubview(reminderNotificationsLabel)
        
        rightSideView.addConstraintsWithFormat("H:[v0(40)]-20-[v1(19)]|", views: reminderButton,contactButton)
        rightSideView.addConstraintsWithFormat("V:|-29-[v0(22)]", views: reminderButton)
        rightSideView.addConstraintsWithFormat("V:|-20-[v0(35)]", views: contactButton)
        if (contactNumberOfNotifications == 0){
            contactNumberBubble.alpha = 0
            contactNotificationsLabel.alpha = 0
        }
        else if (contactNumberOfNotifications < 10) {
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNotificationsLabel)
            contactNotificationsLabel.text = " \(contactNumberOfNotifications)"
        }
        else if (contactNumberOfNotifications >= 10 && contactNumberOfNotifications < 100){
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNotificationsLabel)
        }
        else if (contactNumberOfNotifications >= 100 ){
            if (contactNumberOfNotifications >= 1000){
                contactNotificationsLabel.text = "999"
            }
            rightSideView.addConstraintsWithFormat("H:[v0(20)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-41-[v0(20)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(21)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-41-[v0(20)]", views: contactNotificationsLabel)
        }
        
        
        
        if (reminderNumberOfNotifications == 0){
            reminderNumberBubble.alpha = 0
            reminderNotificationsLabel.alpha = 0
        }
        else if (reminderNumberOfNotifications < 10){
            reminderNumberBubble.layer.cornerRadius = 2.5
            rightSideView.addSubview(reminderNumberBubble)
            
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-70-|", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-69-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNotificationsLabel)
            reminderNotificationsLabel.text = " \(reminderNumberOfNotifications)"
        }
        else if (reminderNumberOfNotifications >= 10 && reminderNumberOfNotifications < 100){
            reminderNumberBubble.layer.cornerRadius = 2.5
            rightSideView.addSubview(reminderNumberBubble)
            
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-70-|", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-69-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNotificationsLabel)
        }
        else if (reminderNumberOfNotifications >= 100){
            if (reminderNumberOfNotifications >= 1000){
                reminderNotificationsLabel.text = "999"
            }
            let wholeReminderBubble = UIView()
            
            let reminderNumberBubble2 = UIView()
            let reminderNumberBubble3 = UIView()
            let reminderNumberBubble4 = UIView()
            
            reminderNumberBubble2.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            reminderNumberBubble3.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            reminderNumberBubble4.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            
            wholeReminderBubble.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            wholeReminderBubble.layer.cornerRadius = 3.0
            rightSideView.addSubview(wholeReminderBubble)
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            
            rightSideView.addConstraintsWithFormat("H:[v0(20)]-68-|", views: wholeReminderBubble)
            rightSideView.addConstraintsWithFormat("V:|-40-[v0(20)]", views: wholeReminderBubble)
            
            
            rightSideView.addConstraintsWithFormat("H:[v0(21)]-67-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-40-[v0(20)]", views: reminderNotificationsLabel)
        }
        
//        let rightSideButtons = UIBarButtonItem(customView: rightSideView)
        
        masterNavBar.addSubview(rightSideView)
        
        masterNavBar.addConstraintsWithFormat("H:|-10-[v0(55)][v1(100)]-10-|", views: leftSideView, rightSideView)
        masterNavBar.addConstraintsWithFormat("V:|[v0(80)]|", views: leftSideView)
        masterNavBar.addConstraintsWithFormat("V:|[v0(80)]|", views: rightSideView)
        
        masterNavBar.backgroundColor = UIColor.whiteColor()
        masterNavBar.userInteractionEnabled = true
        leftSideView.userInteractionEnabled = true
        rightSideView.userInteractionEnabled = true
        self.view.addSubview(masterNavBar)
        
    
//        navigationItem.rightBarButtonItems = [rightSideButtons ]
        
        //Box behind NavBar to ensure correct coloring of NavBar
//        let frame = self.view.frame
//        let NavBarColorFixer = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, view.frame.width, 64))
//        NavBarColorFixer.backgroundColor = UIColor.whiteColor()
//        self.view.addSubview(NavBarColorFixer)
    }

    //When you touch the searchbox, the field changes to this color
    func touchedSearchBox(gesture: UITapGestureRecognizer) {
        searchBox.backgroundColor = UIColor.rgb(176, green: 238, blue: 237)
    }
    
    //When you leave the searchbox, the color reverts
    func leftSearchBox(gesture: UITapGestureRecognizer) {
        searchBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
    }
    
    //When you double tap the navBar, the collection view goes to the top
    func bringNewsFeedToTop(gesture: UITapGestureRecognizer) {
      collectionView?.setContentOffset(CGPointMake(0, 0), animated: true)
    }

}


class FeedCell: UICollectionViewCell {

    //Stuff that is unique to a cell
    var post: Post? {
        didSet {
            let attributedText = NSMutableAttributedString(string: "", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 14)!,
                NSForegroundColorAttributeName: UIColor.rgb(65, green: 64, blue: 66)])
            if let name = post?.name {
                attributedText.appendAttributedString(NSAttributedString(string: name, attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 14)!,
                    NSForegroundColorAttributeName: UIColor.rgb(65, green: 64, blue: 66)]))
                }
                let timeSincePost = 38
                let timeSincePostMessage = "\(timeSincePost)m ago"
                attributedText.appendAttributedString(NSAttributedString(string: "  \(timeSincePostMessage)", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 8)!,
                NSForegroundColorAttributeName: UIColor.rgb(88, green: 89, blue: 91)]))
            
            if let status = post?.statusText{
                statusText.text = status
            }
            
            if let profileImage = post?.profilePic{
                //profileImageView.setImage(ResizeImage(profileImage, targetSize: CGSizeMake(40, 40)) , forState: .Normal)
                profileImageView.setImage(profileImage, forState: .Normal)
            }
           
            
                /*let attachment = NSTextAttachment()
                 attachment.image = UIImage(named: "")
                 attachment.bounds = CGRectMake(0,-2,12,12)
                 attributedText.appendAttributedString(NSAttributedString(attachment: attachment))
                 */ //How to add an image to the end of the label
                
                nameLabel.attributedText = attributedText
    
            
        }
        
    }
  
    
    
    
    override init(frame: CGRect){
        super.init(frame: frame)
        
        setupViews()
    }
    
    //Prevents stupid xcode warning/error
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //Name of the poster, actual text of label is set above
    let nameLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 2
        return label
    }()
    
    //Profile picture of poster, actual image of button is set above
    var profileImageView: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 5.0
        button.layer.masksToBounds = true
        return button
    }()
    
    
    // General Information of poster, actual text is set above
    let statusText: UITextView = {
        let textView = UITextView()
        textView.font = UIFont(name: "Calibri-Light", size: 11)!
        //textView.font = UIFont.systemFontOfSize(11)
        textView.textColor = UIColor.rgb(88, green: 89, blue: 91)
        textView.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        //textView.backgroundColor = UIColor.redColor()
        textView.editable = false
        textView.scrollEnabled = false
        return textView
    }()
    
    
    
    //Button to add event
    let addEventViewButton: UIButton = {

        let view = UIView()
        view.frame = CGRect(x: 0, y: 0, width: 150, height: 150)
        
        let button = UIButton()
        button.setImage(UIImage(named:"icon add")! , forState: .Normal)
        
        let label = UILabel()
        label.text = "Add Event"
        label.font = UIFont(name: "Calibri-Light", size: 5)!
        label.textColor = UIColor.rgb(88, green: 89, blue: 91)
        //label.backgroundColor = UIColor.whiteColor()
        
        
        view.addSubview(button)
        view.addSubview(label)
        
        view.addConstraintsWithFormat("V:|[v0(20)]-3-[v1]", views: button, label)
        view.addConstraintsWithFormat("H:|[v0(20)]|", views: button)
        view.addConstraintsWithFormat("H:|[v0(22)]|", views: label)
        let viewButton = UIButton()
        viewButton.addSubview(view)
        viewButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        //viewButton.backgroundColor = UIColor.whiteColor()
        return viewButton
    }()
    
    //setting the view of each cell
    func setupViews() {
        backgroundColor = UIColor.whiteColor()
        
        addSubview(statusText)
        addSubview(nameLabel)
        addSubview(profileImageView)
        addSubview(addEventViewButton)
        
        //addSubview(dropDownImageButton)
        
        addConstraintsWithFormat("H:|-8-[v0(44)]-8-[v1][v2(23)]-5-|", views: profileImageView, nameLabel, addEventViewButton)
        
        addConstraintsWithFormat("H:|-8-[v0]-2-[v1][v2]-10-|", views: profileImageView, statusText, addEventViewButton)
        addConstraintsWithFormat("V:|-15-[v0]|", views: statusText)
        
        addConstraintsWithFormat("V:|-15-[v0(40)]", views: addEventViewButton)
        addConstraintsWithFormat("V:|-6-[v0]", views: nameLabel)
        addConstraintsWithFormat("V:|-8-[v0(44)]", views: profileImageView)
        
    }
    
}








