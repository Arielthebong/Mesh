//
//  MyProfile.swift
//  Mesh
//
//  Created by Daniel Ssemanda on 8/14/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import Foundation



class MyProfileView: UIViewController{
    
    var cornerQuickAccessButton = UIButton()
    //For handling the tabs and their look
    var isMyInfoPageOpen = true
    let myInfoTab = UIButton()
    let myInfoTabSelectedString = NSMutableAttributedString()
    let myInfoTabString = NSMutableAttributedString()
    let myDocumentsTab = UIButton()
    let myDocumentsTabSelectedString = NSMutableAttributedString()
    let myDocumentsTabString = NSMutableAttributedString()
    var myDocumentsSuperView = UIView()
    
    //For SearchBar in myDocuments Section
    var secondBar = UIView()
    let searchBox = TextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.whiteColor()
        let frame = self.view.frame
       
        //Creates My Info and My Documents Tabs
        createTabs()
        
        //Creating the NavBar
        makeBioSection()
        
        //Makes bottom right corner button
        createCornerButton()
        
        //Creates Phone, Email, Fax, etc. sections
        makeOtherSections()
        
        myDocumentsSuperView = UIView(frame: CGRectMake(0, 108, frame.width, frame.height - 108))
        myDocumentsSuperView.backgroundColor = UIColor.whiteColor()
//        let tappingDocumentsSuperview = UITapGestureRecognizer(target: self, action: #selector(remove))
//        myDocumentsSuperView.addGestureRecognizer(tappingDocumentsSuperview)
        
        secondBar = UIView(frame: CGRectMake(0, 0, view.frame.width, 36))
        secondBar.backgroundColor = UIColor.whiteColor()
        
        let grayBox = UIView()
        grayBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        
        let searchButton = UIButton()
        searchButton.setImage(UIImage(named:"icon search"), forState: .Normal)
        //        searchButton.addTarget(self, action: #selector(makeSegueChange), forControlEvents: UIControlEvents.TouchUpInside)
        
        
        searchBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        //      searchBox.backgroundColor = UIColor.rgb(176, green: 238, blue: 237)
        searchBox.layer.borderWidth = 1.0
        searchBox.layer.borderColor = UIColor.blackColor().CGColor
        searchBox.placeholder = "Type a company name"
        //searchBox.font = UIFont(name: "Calibri-Light", size: 11)!
        searchBox.font = UIFont.systemFontOfSize(11)
        searchBox.layer.cornerRadius = 5
        //      searchBox.hidden = false
        searchBox.addTarget(self, action: #selector(touchedSearchBox), forControlEvents: UIControlEvents.EditingDidBegin)
        searchBox.addTarget(self, action: #selector(leftSearchBox), forControlEvents: UIControlEvents.EditingDidEnd)
        
        
        
        //        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(touchedSearchBox))
        //        secondBar.addGestureRecognizer(tapGesture)
        
        let sortBy = UIButton(type: .System)
        let sortByText = NSMutableAttributedString()
        let sortByFirstPart = NSAttributedString(string: "Sort by", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 11)!, NSForegroundColorAttributeName: UIColor.rgb(88, green: 89, blue: 91)])
        let sortBySecondPart = NSAttributedString(string: " date added", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 11)!, NSForegroundColorAttributeName: UIColor.rgb(228, green: 40, blue: 54)])
        sortByText.appendAttributedString(sortByFirstPart)
        sortByText.appendAttributedString(sortBySecondPart)
        let dropDownAttachment = NSTextAttachment()
        dropDownAttachment.image = UIImage(named: "icon collapse down")
        dropDownAttachment.bounds = CGRectMake(0,0,8,4)
        sortByText.appendAttributedString(NSAttributedString(attachment: dropDownAttachment))
        sortBy.setAttributedTitle(sortByText, forState: .Normal)
        
        
        secondBar.addSubview(searchBox)
        secondBar.addSubview(grayBox)
        secondBar.addSubview(searchButton)
        secondBar.addSubview(sortBy)
        secondBar.addConstraintsWithFormat("H:[v0(18)]-10-|", views: searchButton)
        secondBar.addConstraintsWithFormat("V:|-9-[v0(17)]", views: searchButton)
        secondBar.addConstraintsWithFormat("V:|-6-[v0(24)]", views: searchBox)
        secondBar.addConstraintsWithFormat("H:|-0-[v0(102)]-0-[v1]-2-[v2(37)]|", views: sortBy, searchBox, grayBox)
        secondBar.addConstraintsWithFormat("V:|-6-[v0(24)]", views: grayBox)
        secondBar.addConstraintsWithFormat("V:|-12-[v0(24)]", views: sortBy)

        
        
        myDocumentsSuperView.addSubview(secondBar)
        
//        view.addSubview(myDocumentsSuperView)
        

        view.bringSubviewToFront(cornerQuickAccessButton)
        createAndAddButtonsToNavBar()
    }
    
    //Creates My Info and My Documents Tabs
    func createTabs() {
        let frame = self.view.frame
        
        
        myInfoTab.frame = CGRectMake(0, 65, ceil(frame.width / 2), 40)
        myInfoTab.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        myInfoTab.addTarget(self, action: #selector(myInfoTabClicked), forControlEvents: UIControlEvents.TouchUpInside)
        
        let rightFacingCollapseIcon = NSTextAttachment()
        rightFacingCollapseIcon.image = imageResize(UIImage(named: "icon collapse right white")!, sizeChange: CGSize(width: 10, height: 10))
        
        let leftFacingCollapseIcon = NSTextAttachment()
        leftFacingCollapseIcon.image = imageResize(UIImage(named: "icon collapse left white")!, sizeChange: CGSize(width: 10, height: 10))
        
        let rightAttachmentString = NSAttributedString(attachment: rightFacingCollapseIcon)
        let leftAttachmentString = NSAttributedString(attachment: leftFacingCollapseIcon)
        
        
        let myInfoStringText = NSAttributedString(string: "  My Info  ", attributes: [NSForegroundColorAttributeName: UIColor.whiteColor()])
        myInfoTabSelectedString.appendAttributedString(rightAttachmentString)
        myInfoTabSelectedString.appendAttributedString(myInfoStringText)
        myInfoTabSelectedString.appendAttributedString(leftAttachmentString)
        
        myInfoTabString.appendAttributedString(myInfoStringText)
        myInfoTab.setAttributedTitle(myInfoTabSelectedString, forState: .Normal)
        

    
        self.view.addSubview(myInfoTab)
        
        
        
        myDocumentsTab.frame = CGRectMake(ceil(frame.width / 2) + 3, 65, frame.width - ceil(frame.width / 2) - 3 , 40)
        myDocumentsTab.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        myDocumentsTab.addTarget(self, action: #selector(myDocumentsTabClicked), forControlEvents: UIControlEvents.TouchUpInside)
        
        let myDocumentsStringText = NSAttributedString(string: " My Documents ", attributes: [NSForegroundColorAttributeName: UIColor.whiteColor()])
        
        myDocumentsTabSelectedString.appendAttributedString(rightAttachmentString)
        myDocumentsTabSelectedString.appendAttributedString(myDocumentsStringText)
        myDocumentsTabSelectedString.appendAttributedString(leftAttachmentString)
        
        myDocumentsTabString.appendAttributedString(myDocumentsStringText)
        
        myDocumentsTab.setAttributedTitle(myDocumentsTabString, forState: .Normal)
        self.view.addSubview(myDocumentsTab)
    }
    
    //When you touch the searchbox, the field changes to this color
    func touchedSearchBox(gesture: UITapGestureRecognizer) {
        searchBox.backgroundColor = UIColor.rgb(176, green: 238, blue: 237)
    }
    
    //When you leave the searchbox, the color reverts
    func leftSearchBox(gesture: UITapGestureRecognizer) {
        searchBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
    }

    
    func myDocumentsTabClicked() {
        if (isMyInfoPageOpen) {
           myDocumentsTab.setAttributedTitle(myDocumentsTabSelectedString, forState: .Normal)
           myInfoTab.setAttributedTitle(myInfoTabString, forState: .Normal)
           view.addSubview(myDocumentsSuperView)
           isMyInfoPageOpen = false
        }
    }
    
    func myInfoTabClicked() {
        if(!isMyInfoPageOpen){
            myDocumentsTab.setAttributedTitle(myDocumentsTabString, forState: .Normal)
            myInfoTab.setAttributedTitle(myInfoTabSelectedString, forState: .Normal)
            myDocumentsSuperView.removeFromSuperview()
            isMyInfoPageOpen = true
        }
    }
    
    //Creating the NavBar
    func createAndAddButtonsToNavBar() {
        //Creating Buttons to be stored on left and right side of NavBar
        let bounds = UIScreen.mainScreen().bounds
        let width = bounds.size.width
        //        let height = bounds.size.height
        
        let masterNavBar = UIView(frame: CGRectMake(0, 0, width, 65))
        let grayLine = UIView(frame: CGRectMake(0, 65, width, 1))
        grayLine.backgroundColor = UIColor.lightGrayColor()
        self.view.addSubview(grayLine)
        
        let leftSideView = UIView()
        leftSideView.frame = CGRectMake(0, 0, 55, 80)
        //        leftSideView.backgroundColor = UIColor.blueColor()
        
        let logoButton: UIButton = {
            let button = UIButton()
            button.setImage(navigationLogoImage, forState: .Normal)
            button.addTarget(self, action: #selector(bringOutTheBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
            button.frame = CGRectMake(0, 0, 40, 40)
            return button
        }()
        
        let collapseRight = UIImage(named: "icon collapse right")!
        
        let collapseRightButton : UIButton = {
            let button = UIButton()
            button.setImage(collapseRight, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
            button.addTarget(self, action: #selector(bringOutTheBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
            return button
        }()
        
        //        let newsFeedBarButton = UIBarButtonItem(title: "News Feed", style: UIBarButtonItemStyle.Plain, target: self, action: nil)
        //        newsFeedBarButton.tintColor = UIColor.rgb(228, green: 40, blue: 54)
        //        let font = UIFont(name: "Calibri-Light", size: 20)
        //        newsFeedBarButton.setTitleTextAttributes([NSFontAttributeName: font!], forState: UIControlState.Normal )
        let barNameLabel = UILabel()
        barNameLabel.text = "My Profile"
        barNameLabel.font = UIFont(name: "Calibri-Light", size: 28)
        barNameLabel.textColor = UIColor.rgb(228, green: 40, blue: 54)
        
        leftSideView.addSubview(logoButton)
        leftSideView.addSubview(collapseRightButton)
        leftSideView.addSubview(barNameLabel)
        leftSideView.addConstraintsWithFormat("H:|[v0(40)]-0-[v1(8)]-7-[v2]", views: logoButton, collapseRightButton, barNameLabel)
        leftSideView.addConstraintsWithFormat("V:|-19-[v0(40)]", views: logoButton)
        leftSideView.addConstraintsWithFormat("V:|-44-[v0(15)]", views: collapseRightButton)
        leftSideView.addConstraintsWithFormat("V:|-28-[v0]", views: barNameLabel)
        
        //        let leftSideButtons = UIBarButtonItem(customView: leftSideView)
        
        
        masterNavBar.addSubview(leftSideView)
        
        //        navigationItem.leftBarButtonItems = [ leftSideButtons, newsFeedBarButton]
        
        
        
        let rightSideView = UIView()
        rightSideView.frame = CGRectMake(0, 0, 100, 80)
        
        
        let reminderButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(named:"icon reminder")!, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
//            button.addTarget(self, action: #selector(reminderButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
            return button
        }()
        
        let contactButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(named:"icon contact")!, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
            //button.addTarget(<#T##target: AnyObject?##AnyObject?#>, action: <#T##Selector#>, forControlEvents: <#T##UIControlEvents#>)
            return button
        }()
        
        let contactNumberBubble = UIImageView(image: UIImage(named: "icon number bubble"))
        
        
        
        let reminderNumberBubble = UIView()
        reminderNumberBubble.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        
        
        //        rightSideView.backgroundColor = UIColor.blueColor()
        
        let contactNotificationsLabel = UILabel()
        contactNotificationsLabel.text = "\(contactNumberOfNotifications)"
        contactNotificationsLabel.textColor = UIColor.whiteColor()
        contactNotificationsLabel.font = UIFont.boldSystemFontOfSize(10)
        
        let reminderNotificationsLabel = UILabel()
        reminderNotificationsLabel.text = "\(reminderNumberOfNotifications)"
        reminderNotificationsLabel.textColor = UIColor.whiteColor()
        reminderNotificationsLabel.font = UIFont.boldSystemFontOfSize(10)
        
        rightSideView.addSubview(reminderButton)
        rightSideView.addSubview(contactButton)
        rightSideView.addSubview(contactNumberBubble)
        rightSideView.addSubview(contactNotificationsLabel)
        rightSideView.addSubview(reminderNotificationsLabel)
        
        rightSideView.addConstraintsWithFormat("H:[v0(40)]-20-[v1(19)]|", views: reminderButton,contactButton)
        rightSideView.addConstraintsWithFormat("V:|-29-[v0(22)]", views: reminderButton)
        rightSideView.addConstraintsWithFormat("V:|-20-[v0(35)]", views: contactButton)
        if (contactNumberOfNotifications == 0){
            contactNumberBubble.alpha = 0
            contactNotificationsLabel.alpha = 0
        }
        else if (contactNumberOfNotifications < 10) {
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNotificationsLabel)
            contactNotificationsLabel.text = " \(contactNumberOfNotifications)"
        }
        else if (contactNumberOfNotifications >= 10 && contactNumberOfNotifications < 100){
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNotificationsLabel)
        }
        else if (contactNumberOfNotifications >= 100 ){
            if (contactNumberOfNotifications >= 1000){
                contactNotificationsLabel.text = "999"
            }
            rightSideView.addConstraintsWithFormat("H:[v0(20)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-41-[v0(20)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(21)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-41-[v0(20)]", views: contactNotificationsLabel)
        }
        
        
        
        if (reminderNumberOfNotifications == 0){
            reminderNumberBubble.alpha = 0
            reminderNotificationsLabel.alpha = 0
        }
        else if (reminderNumberOfNotifications < 10){
            reminderNumberBubble.layer.cornerRadius = 2.5
            rightSideView.addSubview(reminderNumberBubble)
            
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-70-|", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-69-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNotificationsLabel)
            reminderNotificationsLabel.text = " \(reminderNumberOfNotifications)"
        }
        else if (reminderNumberOfNotifications >= 10 && reminderNumberOfNotifications < 100){
            reminderNumberBubble.layer.cornerRadius = 2.5
            rightSideView.addSubview(reminderNumberBubble)
            
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-70-|", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-69-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNotificationsLabel)
        }
        else if (reminderNumberOfNotifications >= 100){
            if (reminderNumberOfNotifications >= 1000){
                reminderNotificationsLabel.text = "999"
            }
            let wholeReminderBubble = UIView()
            
            let reminderNumberBubble2 = UIView()
            let reminderNumberBubble3 = UIView()
            let reminderNumberBubble4 = UIView()
            
            reminderNumberBubble2.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            reminderNumberBubble3.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            reminderNumberBubble4.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            
            wholeReminderBubble.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            wholeReminderBubble.layer.cornerRadius = 3.0
            rightSideView.addSubview(wholeReminderBubble)
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            
            rightSideView.addConstraintsWithFormat("H:[v0(20)]-68-|", views: wholeReminderBubble)
            rightSideView.addConstraintsWithFormat("V:|-40-[v0(20)]", views: wholeReminderBubble)
            
            
            rightSideView.addConstraintsWithFormat("H:[v0(21)]-67-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-40-[v0(20)]", views: reminderNotificationsLabel)
        }
        
        //        let rightSideButtons = UIBarButtonItem(customView: rightSideView)
        
        masterNavBar.addSubview(rightSideView)
        
        masterNavBar.addConstraintsWithFormat("H:|-10-[v0(55)][v1(100)]-10-|", views: leftSideView, rightSideView)
        masterNavBar.addConstraintsWithFormat("V:|[v0(80)]|", views: leftSideView)
        masterNavBar.addConstraintsWithFormat("V:|[v0(80)]|", views: rightSideView)
        
        masterNavBar.backgroundColor = UIColor.whiteColor()
        masterNavBar.userInteractionEnabled = true
        leftSideView.userInteractionEnabled = true
        rightSideView.userInteractionEnabled = true
        self.view.addSubview(masterNavBar)
        
        
        //        navigationItem.rightBarButtonItems = [rightSideButtons ]
        
        //Box behind NavBar to ensure correct coloring of NavBar
        //        let frame = self.view.frame
        //        let NavBarColorFixer = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, view.frame.width, 64))
        //        NavBarColorFixer.backgroundColor = UIColor.whiteColor()
        //        self.view.addSubview(NavBarColorFixer)
    }
    
    //Creates first biographical info section
    func makeBioSection() {
        let frame = self.view.frame
        let myInfoView = UIView(frame: CGRectMake(0, 108, frame.width, 120))
        myInfoView.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        self.view.addSubview(myInfoView)
        
        let myProfilePic = UIImageView()
        myProfilePic.backgroundColor = UIColor.whiteColor()
        
        let myNameLabel = UILabel()
        myNameLabel.text = "John Smith"
        myNameLabel.font = UIFont(name: "Calibri-Light", size: 34)
        myNameLabel.textColor = UIColor.whiteColor()
        
        let myCompanyLabel = UILabel()
        myCompanyLabel.text = "Yale"
        myCompanyLabel.font = UIFont(name: "Calibri-Light", size: 18)
        myCompanyLabel.textColor = UIColor.whiteColor()
        
        let myPositionLabel = UILabel()
        myPositionLabel.text = "Marketing Management"
        myPositionLabel.font = UIFont(name: "Calibri-Light", size: 14)
        myPositionLabel.textColor = UIColor.whiteColor()
        
        let editButton = UIButton()
        let editLabel = UILabel()
        editLabel.text = "Edit"
        editLabel.textColor = UIColor.whiteColor()
        editLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let editIcon = UIImageView()
        editIcon.image = UIImage(named: "icon sidebar network")
        editButton.addSubview(editLabel)
        editButton.addSubview(editIcon)
        editButton.addConstraintsWithFormat("H:[v0(40)][v1(25)]|", views: editLabel, editIcon)
        editButton.addConstraintsWithFormat("V:[v0(20)]|", views: editLabel)
        editButton.addConstraintsWithFormat("V:|[v0(25)]|", views: editIcon)
        
        
        
        myInfoView.addSubview(myProfilePic)
        myInfoView.addSubview(myNameLabel)
        myInfoView.addSubview(myCompanyLabel)
        myInfoView.addSubview(myPositionLabel)
        myInfoView.addSubview(editButton)
        myInfoView.addConstraintsWithFormat("H:|-10-[v0(100)]-5-[v1]|", views: myProfilePic, myNameLabel)
        myInfoView.addConstraintsWithFormat("V:|-10-[v0(100)]", views: myProfilePic)
        myInfoView.addConstraintsWithFormat("V:|-10-[v0]", views: myNameLabel)
        myInfoView.addConstraintsWithFormat("V:[v0]-5-[v1]-10-|", views: myCompanyLabel, myPositionLabel)
        myInfoView.addConstraintsWithFormat("H:|-10-[v0(100)]-5-[v1]", views: myProfilePic, myCompanyLabel)
        myInfoView.addConstraintsWithFormat("H:|-10-[v0(100)]-5-[v1]", views: myProfilePic, myPositionLabel)
        myInfoView.addConstraintsWithFormat("H:[v0(55)]|", views: editButton)
        myInfoView.addConstraintsWithFormat("V:[v0(25)]-10-|", views: editButton)
    }
    
    //Creates Phone, Email, Fax, etc. sections
    func makeOtherSections(){
        let frame = self.view.frame
        let sizeCalculation = floor((frame.height - 318) / 4)
        
        let phoneSection = UIView(frame: CGRectMake(0, 238, frame.width, sizeCalculation + 20))
        phoneSection.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        let phoneIcon = UIImageView()
        phoneIcon.image = UIImage(named: "icon number bubble")
        let phoneLabel = UILabel()
        phoneLabel.text = "Phone"
        phoneLabel.textColor = UIColor.rgb(65, green: 64, blue: 66)
        phoneLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let mobilePhoneNumber = UILabel()
        mobilePhoneNumber.text = "(555) 987-1234"
        mobilePhoneNumber.textColor = UIColor.rgb(65, green: 64, blue: 66)
        mobilePhoneNumber.font = UIFont(name: "Calibri-Light", size: 18)
        let mobilePhoneLabel = UILabel()
        mobilePhoneLabel.text = "Mobile"
        mobilePhoneLabel.textColor = UIColor.rgb(147, green: 149, blue: 152)
        mobilePhoneLabel.font = UIFont(name: "Calibri-Light", size: 14)
        let workPhoneNumber = UILabel()
        workPhoneNumber.text = "(444) 569-1234"
        workPhoneNumber.textColor = UIColor.rgb(65, green: 64, blue: 66)
        workPhoneNumber.font = UIFont(name: "Calibri-Light", size: 18)
        let workPhoneLabel = UILabel()
        workPhoneLabel.text = "Work"
        workPhoneLabel.textColor = UIColor.rgb(147, green: 149, blue: 152)
        workPhoneLabel.font = UIFont(name: "Calibri-Light", size: 14)
        
        
        phoneSection.addSubview(phoneIcon)
        phoneSection.addSubview(phoneLabel)
        phoneSection.addSubview(mobilePhoneNumber)
        phoneSection.addSubview(mobilePhoneLabel)
        phoneSection.addSubview(workPhoneNumber)
        phoneSection.addSubview(workPhoneLabel)
        phoneSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: phoneIcon, phoneLabel)
        phoneSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1][v2]", views: phoneLabel, mobilePhoneNumber, mobilePhoneLabel)
        phoneSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1][v2]", views: phoneLabel, workPhoneNumber, workPhoneLabel)
        phoneSection.addConstraintsWithFormat("V:|-10-[v0(25)]", views: phoneIcon)
        phoneSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]-10-[v2]", views: phoneIcon, mobilePhoneNumber, workPhoneNumber)
        phoneSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]-10-[v2]", views: phoneIcon, mobilePhoneNumber, workPhoneLabel)
        phoneSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: phoneIcon, mobilePhoneLabel)
        
        
        
        self.view.addSubview(phoneSection)
        
        let emailSectionYPos = 238 + sizeCalculation + 30
        let emailSection = UIView(frame: CGRectMake(0, emailSectionYPos, frame.width, sizeCalculation + 20))
        emailSection.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        let emailIcon = UIImageView()
        emailIcon.image = UIImage(named: "icon number bubble")
        let emailLabel = UILabel()
        emailLabel.text = "Email"
        emailLabel.textColor = UIColor.rgb(65, green: 64, blue: 66)
        emailLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let workEmailText = UILabel()
        workEmailText.text = "jsmith@yale.edu"
        workEmailText.textColor = UIColor.rgb(65, green: 64, blue: 66)
        workEmailText.font = UIFont(name: "Calibri-Light", size: 18)
        let workEmailLabel = UILabel()
        workEmailLabel.text = "Work"
        workEmailLabel.textColor = UIColor.rgb(147, green: 149, blue: 152)
        workEmailLabel.font = UIFont(name: "Calibri-Light", size: 14)
        let personalEmailText = UILabel()
        personalEmailText.text = "jsmith12@gmail.com"
        personalEmailText.textColor = UIColor.rgb(65, green: 64, blue: 66)
        personalEmailText.font = UIFont(name: "Calibri-Light", size: 18)
        let personalEmailLabel = UILabel()
        personalEmailLabel.text = "Work"
        personalEmailLabel.textColor = UIColor.rgb(147, green: 149, blue: 152)
        personalEmailLabel.font = UIFont(name: "Calibri-Light", size: 14)
        
        
        
        emailSection.addSubview(emailIcon)
        emailSection.addSubview(emailLabel)
        emailSection.addSubview(workEmailText)
        emailSection.addSubview(workEmailLabel)
        emailSection.addSubview(personalEmailText)
        emailSection.addSubview(personalEmailLabel)
        emailSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: emailIcon, emailLabel)
        emailSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1][v2]", views: emailLabel, workEmailText, workEmailLabel)
        emailSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1][v2]", views: emailLabel, personalEmailText, personalEmailLabel)
        emailSection.addConstraintsWithFormat("V:|-10-[v0(25)]", views: emailIcon)
        emailSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]-10-[v2]", views: emailIcon, workEmailText, personalEmailText)
        emailSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]-10-[v2]", views: emailIcon, workEmailText, personalEmailLabel)
        emailSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: emailIcon, workEmailLabel)
        
        self.view.addSubview(emailSection)
        
        
        
        let faxSectionYPos = emailSectionYPos + sizeCalculation + 30
        let faxSection = UIView(frame: CGRectMake(0, faxSectionYPos, frame.width, sizeCalculation))
        faxSection.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        let faxIcon = UIImageView()
        faxIcon.image = UIImage(named: "icon number bubble")
        let faxLabel = UILabel()
        faxLabel.text = "Fax"
        faxLabel.textColor = UIColor.rgb(65, green: 64, blue: 66)
        faxLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let faxNumberText = UILabel()
        faxNumberText.text = "+1-212-9876543"
        faxNumberText.textColor = UIColor.rgb(65, green: 64, blue: 66)
        faxNumberText.font = UIFont(name: "Calibri-Light", size: 18)
        
        faxSection.addSubview(faxIcon)
        faxSection.addSubview(faxLabel)
        faxSection.addSubview(faxNumberText)
        faxSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: faxIcon, faxLabel)
        faxSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1]", views: faxLabel, faxNumberText)
        faxSection.addConstraintsWithFormat("V:|-10-[v0(25)]", views: faxIcon)
        faxSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: faxIcon, faxNumberText)
        
        self.view.addSubview(faxSection)
        
        
        
        let officeSectionYPos = faxSectionYPos + sizeCalculation + 10
        let officeSection = UIView(frame: CGRectMake(0, officeSectionYPos, frame.width, sizeCalculation))
        officeSection.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        let officeIcon = UIImageView()
        officeIcon.image = UIImage(named: "icon number bubble")
        let officeLabel = UILabel()
        officeLabel.text = "Office"
        officeLabel.textColor = UIColor.rgb(65, green: 64, blue: 66)
        officeLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let officeLocation = UILabel()
        officeLocation.text = "321 Baker Street NY, NY 02345"
        officeLocation.textColor = UIColor.rgb(65, green: 64, blue: 66)
        officeLocation.font = UIFont(name: "Calibri-Light", size: 18)
        
        officeSection.addSubview(officeIcon)
        officeSection.addSubview(officeLabel)
        officeSection.addSubview(officeLocation)
        officeSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: officeIcon, officeLabel)
        officeSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1]", views: officeLabel, officeLocation)
        officeSection.addConstraintsWithFormat("V:|-10-[v0(25)]", views: officeIcon)
        officeSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: officeIcon, officeLocation)
        
        self.view.addSubview(officeSection)
 
    }
    
    //Bringing out the Big Red Menu
    func bringOutTheBigRedMenu(){
        let frame = self.view.frame
        bigRedMenu = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, ceil(self.view.frame.width * (2/3))  , frame.height))
        bigRedMenu.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        let slideInFromLeftTransition = CATransition()
        slideInFromLeftTransition.type = kCATransitionPush
        slideInFromLeftTransition.subtype = kCATransitionFromLeft
        slideInFromLeftTransition.duration = 0.3
        slideInFromLeftTransition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        slideInFromLeftTransition.fillMode = kCAFillModeRemoved
        bigRedMenu.layer.addAnimation(slideInFromLeftTransition, forKey: "slideInFromLeftTransition")
        
        let  whiteCollapseLeft = UIButton(type: .Custom)
        whiteCollapseLeft.setImage(UIImage(named: "icon collapse left white"), forState: .Normal)
        whiteCollapseLeft.addTarget(self , action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        
        let navigationButton = UIButton(type: .Custom)
        navigationButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        let stringFormat = NSMutableAttributedString(string: "Navigation", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 28)!, NSForegroundColorAttributeName: UIColor.whiteColor()])
        navigationButton.setAttributedTitle(stringFormat, forState: .Normal)
        navigationButton.addTarget(self , action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        //        self.navigationController.addChildViewController(bigRedCollectionView) //Seems to be unnecessary
        bigRedCollectionView.didMoveToParentViewController(self.navigationController)
        
        let settingsButton = UIButton(type: .Custom)
        settingsButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        let stringFormat2 = NSMutableAttributedString(string: "Settings", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 28)!, NSForegroundColorAttributeName: UIColor.whiteColor()])
        settingsButton.setAttributedTitle(stringFormat2, forState: .Normal)
        //        settingsButton.addTarget(<#T##target: AnyObject?##AnyObject?#>, action: <#T##Selector#>, forControlEvents: <#T##UIControlEvents#>)
        
        let settingsLogo = UIButton(type: .Custom)
        settingsLogo.setImage(UIImage(named: "icon sidebar settings"), forState: .Normal)
        //        settingsLogo.addTarget(<#T##target: AnyObject?##AnyObject?#>, action: <#T##Selector#>, forControlEvents: <#T##UIControlEvents#>)
        
        let whiteLogo = UIButton(type: .Custom)
        whiteLogo.setImage( UIImage(named: "mesh logo small white"), forState: .Normal)
        whiteLogo.addTarget(self, action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        bigRedMenu.addSubview(whiteLogo)
        bigRedMenu.addSubview(whiteCollapseLeft)
        bigRedMenu.addSubview(navigationButton)
        bigRedMenu.addSubview(settingsLogo)
        bigRedMenu.addSubview(settingsButton)
        bigRedMenu.addSubview(bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|-15-[v0(40)][v1(8)]-8-[v2]", views: whiteLogo, whiteCollapseLeft, navigationButton)
        bigRedMenu.addConstraintsWithFormat("V:|-19-[v0(40)]", views: whiteLogo)
        bigRedMenu.addConstraintsWithFormat("V:|-44-[v0(15)]", views: whiteCollapseLeft)
        bigRedMenu.addConstraintsWithFormat("V:|-23-[v0(40)]", views: navigationButton)
        bigRedMenu.addConstraintsWithFormat("V:|-70-[v0]-70-|", views: bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|[v0]|", views: bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|-20-[v0(30)]-8-[v1]", views: settingsLogo, settingsButton)
        bigRedMenu.addConstraintsWithFormat("V:[v0(30)]-15-|", views: settingsLogo)
        bigRedMenu.addConstraintsWithFormat("V:[v0]-10-|", views: settingsButton)
        view.addSubview(bigRedMenu)
        view.bringSubviewToFront(bigRedMenu)
    }
    
    //When the Big Red Menu needs to go away
    func removeBigRedMenu(){
        let menuWidth = bigRedMenu.bounds.width
        
        let offstageLeft = CGAffineTransformMakeTranslation( -menuWidth, 0)
        UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            bigRedMenu.transform = offstageLeft
            }, completion: {(finished:Bool) in
                self.finishOffBigRedMenu()
        })
        
    }
    
    func finishOffBigRedMenu() {
        bigRedMenu.removeFromSuperview()
    }
    
    //Makes bottom right corner button
    func createCornerButton(){
        cornerQuickAccessButton = UIButton(frame: CGRectMake(view.frame.width - 75, view.frame.height - 75, 65, 65))
        cornerQuickAccessButton.setImage(UIImage(named: "icon contact add"), forState: .Normal)
        cornerQuickAccessButton.addTarget(self, action: #selector(bringCornerMenu), forControlEvents: .TouchUpInside)
        cornerQuickAccessButton.alpha = 0.5
        view.addSubview(cornerQuickAccessButton)
        
    }
    
    //When you hit the lower right hand corner button
    func bringCornerMenu() {
        if (!cornerMenuBool){
            cornerMenuBool = true
            let frame = self.view.frame
            dimming = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, view.frame.width, view.frame.height))
            dimming.backgroundColor = UIColor.whiteColor()
            dimming.alpha = 0.5
            
            let slideInFromBottomTransition = CATransition()
            slideInFromBottomTransition.type = kCATransitionPush
            slideInFromBottomTransition.subtype = kCATransitionFromBottom
            slideInFromBottomTransition.duration = 0.3
            slideInFromBottomTransition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
            slideInFromBottomTransition.fillMode = kCAFillModeRemoved
            
            addContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 183, view.frame.height - 53, 103, 25))
            addContactLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            addContactLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            addNearbyContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 113, 103, 25))
            addNearbyContactLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            addNearbyContactLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            addNearbyContactIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 125, 50, 50))
            addNearbyContactIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            addNearbyContactIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            scanQRCodeLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 163, 103, 25))
            scanQRCodeLabelPic.setImage( UIImage(named: "scan qr bubble text"), forState: .Normal)
            scanQRCodeLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            scanQRCodeIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 175, 50, 50))
            scanQRCodeIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            scanQRCodeIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            myQRCodeLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 213, 103, 25))
            myQRCodeLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            myQRCodeLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            myQRCodeIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 225, 50, 50))
            myQRCodeIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            myQRCodeIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            
            cornerQuickAccessButton.removeFromSuperview()
            view.addSubview(dimming)
            view.addSubview(cornerQuickAccessButton)
            view.addSubview(addContactLabelPic)
            view.addSubview(addNearbyContactLabelPic)
            view.addSubview(addNearbyContactIcon)
            view.addSubview(scanQRCodeLabelPic)
            view.addSubview(scanQRCodeIcon)
            view.addSubview(myQRCodeLabelPic)
            view.addSubview(myQRCodeIcon)
            cornerQuickAccessButton.alpha = 1
            
            
            //
            //            addContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 183, view.frame.height + 1, 103, 25))
            //        UIView.animateWithDuration(0.3, delay: 0.1, options: UIViewAnimationOptions.CurveEaseIn , animations: {
            //            addContactLabelPic = UIButton(frame: CGRectMake(self.view.frame.width - 183, self.view.frame.height - 53, 103, 25))
            //        }, completion: nil)
            //
            
            let tapDimmingView = UITapGestureRecognizer(target: self, action: #selector(removeCornerMenu))
            dimming.addGestureRecognizer(tapDimmingView)
            let tapDimmingView2 = UITapGestureRecognizer(target: self, action: #selector(removeCornerMenu2))
            masterNavBar.addGestureRecognizer(tapDimmingView2)
            //        view.addConstraintsWithFormat("H:|", views: <#T##UIView...##UIView#>)
        }
        
    }
    
    //Used to remove corner menu
    func removeCornerMenu(gesture: UITapGestureRecognizer){
        dimming.removeFromSuperview()
        addContactLabelPic.removeFromSuperview()
        addNearbyContactLabelPic.removeFromSuperview()
        addNearbyContactIcon.removeFromSuperview()
        scanQRCodeLabelPic.removeFromSuperview()
        scanQRCodeIcon.removeFromSuperview()
        myQRCodeLabelPic.removeFromSuperview()
        myQRCodeIcon.removeFromSuperview()
        cornerQuickAccessButton.alpha = 0.5
        cornerMenuBool = false
    }
    
    //Had to make another just for the NavBar :(
    func removeCornerMenu2(gesture: UITapGestureRecognizer){
        dimming.removeFromSuperview()
        addContactLabelPic.removeFromSuperview()
        
        cornerMenuBool = false
    }
    
    
}