//
//  NewsFeed.swift
//  Mesh
//
//  Created by Daniel Ssemanda on 8/4/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import UIKit
import AVFoundation

let cellId = "cellId"
var navigationLogoImage = UIImage(named:"mesh logo login")!
//let navBar: UINavigationItem = UINavigationItem()
var masterNavBar = UIView()
var posts: [Post] = []
var secondBar = UIView()
let searchBox = TextField()

var lastScrollOffset: CGFloat = 0

var reminderNumberOfNotifications = 999
var contactNumberOfNotifications = 999
var bigRedMenu = UIView()
let bigRedCollectionView = BigRedCollectionView(collectionViewLayout: UICollectionViewFlowLayout())


class Post{
    var name: String?
    var statusText: String?
    var profilePic: UIImage?
}


class FeedController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    let customCellIdentifier = "customCellIdentifier"
    var bigRedMenuBool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let frame = self.view.frame
        secondBar = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y + 66, view.frame.width, 36))
//        self.navigationController?.navigationBarHidden = true
        
        
//        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
//        swipeUp.direction = UISwipeGestureRecognizerDirection.Up
        
        //Deals with tapping collectionview and navbar when stuff is open
//        thingsToDoWhenNavBarOrCollectionViewTapped()
        
        //Manually constructing posts
        customCreatedPosts()
        
        //Creating the a second NavBar to store search button
        createSecondNavBar()
        
        //navigationItem.title = ""
        
        //removes atomatic space for navbar inherent within collection view
        self.automaticallyAdjustsScrollViewInsets = false
        
        //Creates the top NavBar Buttons
//        createAndAddButtonsToNavBar()
       
//        let myQRCodeImage = UIImageView(image:  UIImage(named: "icon qr bubble"))
//        let scanQRCodeLabel = UIImageView(image:  UIImage(named: "scan qr bubble text"))
        
        //Quick NavBar Setup stuff
        collectionView?.alwaysBounceVertical = true //Nice bounce effect when scrolling
        collectionView?.backgroundColor = UIColor.whiteColor()
        collectionView?.registerClass(FeedCell.self, forCellWithReuseIdentifier: cellId)
        
    }
    
    override func viewDidAppear(animated: Bool) {
        masterPageIdentificationNum = 0
        let cell0 = bigRedCollectionView.collectionView!.cellForItemAtIndexPath(NSIndexPath(forRow: 0, inSection: 0))
        cell0?.contentView.backgroundColor = UIColor.lightGrayColor()
        
        let cell1 = bigRedCollectionView.collectionView!.cellForItemAtIndexPath(NSIndexPath(forRow: 1, inSection: 0))
        cell1?.contentView.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        let cell2 = bigRedCollectionView.collectionView!.cellForItemAtIndexPath(NSIndexPath(forRow: 2, inSection: 0))
        cell2?.contentView.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        let cell3 = bigRedCollectionView.collectionView!.cellForItemAtIndexPath(NSIndexPath(forRow: 3, inSection: 0))
        cell3?.contentView.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        masterView.barNameLabel.text = "News Feed"
        
        UIView.animateWithDuration(0.3, animations: {
            cornerQuickAccessButton.alpha = 1
        })
    }
    
    //Manually constructing posts
    func customCreatedPosts(){
        let postDan = Post()
        postDan.name = "The Boston Consulting Group"
        postDan.statusText = "Booth Will be Open at Yale Career Fair"
        postDan.profilePic = UIImage(named: "bcg_Logo")
        
        let postMawi = Post()
        postMawi.name = "Omar Zaki"
        postMawi.statusText = "Don't ever play yourself"
        postMawi.profilePic = UIImage(named: "Hillary")
        
        //Adding manually constructed posts to Array
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postMawi)
        posts.append(postMawi)
        posts.append(postMawi)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
        posts.append(postMawi)
        posts.append(postDan)
    }
    
    
    //Setting where the collectionView will be located and its size
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        let frame = self.view.frame
        self.collectionView!.frame = CGRectMake(frame.origin.x, frame.origin.y + 66, frame.size.width, frame.size.height - 66)
    }
    
    //How many total cells will be displayed
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return posts.count
    }
    
    //Things that are true for all cells
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        //Stuff that is true for all cells
        let feedCell =  collectionView.dequeueReusableCellWithReuseIdentifier(cellId, forIndexPath: indexPath) as! FeedCell
        feedCell.contentView.backgroundColor = UIColor.rgb(230, green: 231, blue: 232) //cell background color
        
        feedCell.post = posts[indexPath.item]
        return feedCell
    }
    
    //Sets the cize of each cell
    func collectionView(collectionView: UICollectionView, layout collectViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        
        if let statusText = posts[indexPath.item].statusText {
            
            let heightOfText = statusText.heightWithConstrainedWidth(286, font: UIFont(name: "Calibri-Light", size: 11)!)
            
            if heightOfText <= 22 {
                //print("The given height of this cell is 60")
                return CGSizeMake(view.frame.width, 60)
            }
            else {
                let numberOfLines = heightOfText/11
                    
                let changingNum = (numberOfLines - 2) * 3
                let adjustment = heightOfText - (22 - changingNum)
                //print("This is the changingNum used for the number below: \(changingNum)")
                //print("The given height of this cell is \(60 + adjustment)")
                return CGSizeMake(view.frame.width, 60 + adjustment)
            }
            
            
        }
        
        return CGSizeMake(view.frame.width, 60) //height of each cell
    }
    
    //Sets the distance between cells and the top of the view
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
    let frame : CGRect = self.view.frame
    let margin  = (frame.width - 90 * 3) / 6.0
    return UIEdgeInsetsMake(36, margin, 10, margin)  //First number sets distance from the top
    
    }
    
    //Function to handle the effects of screen rotation
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransitionToSize(size, withTransitionCoordinator: coordinator)
        
        collectionView?.collectionViewLayout.invalidateLayout()
    }

    //Deals with tapping outside of keyboard and brings newsfeed to top when NavBar double tapped
//    func thingsToDoWhenNavBarOrCollectionViewTapped() {
//        
//        let tappingCollectionView = UITapGestureRecognizer(target: self, action: #selector(removeBigRedMenu2))
//        self.collectionView?.addGestureRecognizer(tappingCollectionView)
//        
//      
//        
//    }
    
    //Keeps track of scrolling up or down and whether at top or bottom
    override func scrollViewDidScroll(scrollView: UIScrollView) {
        let scrollViewHeight = scrollView.frame.size.height;
        let scrollContentSizeHeight = scrollView.contentSize.height;
        let scrollOffset = scrollView.contentOffset.y;
        
        if (lastScrollOffset > scrollOffset && scrollOffset != 0 && (scrollOffset + scrollViewHeight <= scrollContentSizeHeight)){
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                secondBar.alpha = 1
                }, completion: nil)
      
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                cornerQuickAccessButton.alpha = 1
                }, completion: nil)
        }
        else if (lastScrollOffset < scrollOffset && (scrollOffset + scrollViewHeight != scrollContentSizeHeight) && scrollOffset >= 0){
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                secondBar.alpha = 0
                }, completion: nil)
            
        }
        
        lastScrollOffset = scrollOffset
        
        if (scrollOffset == 0)
        {
            print("Im at the top")
            secondBar.alpha = 1
            
            
        }
        else if (scrollOffset + scrollViewHeight == scrollContentSizeHeight)
        {
            print("Im at the bottom!!!")
            secondBar.alpha = 0
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                cornerQuickAccessButton.alpha = 0.2
                }, completion: nil)
        }
        
    }
    
    //Lightening the corner button
//    override func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
//        UIView.animateWithDuration(0.5, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
//            CornerQuickAccessButton.alpha = 1
//            }, completion: nil)
//    }
    
    //Lightening the corner button
//    override func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
//        UIView.animateWithDuration(0.5, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
//            CornerQuickAccessButton.alpha = 1
//            }, completion: nil)
//    }
    
    
    
   
    
    
    

    
       //Creating the a second NavBar to store search button
    func createSecondNavBar() {
//        let frame = self.view.frame
        secondBar.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(secondBar)
        
        let grayBox = UIView()
        grayBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        
        let searchButton = UIButton()
        searchButton.setImage(UIImage(named:"icon search"), forState: .Normal)
//        searchButton.addTarget(self, action: #selector(makeSegueChange), forControlEvents: UIControlEvents.TouchUpInside)
        
        
        searchBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        //      searchBox.backgroundColor = UIColor.rgb(176, green: 238, blue: 237)
        searchBox.layer.borderWidth = 1.0
        searchBox.layer.borderColor = UIColor.blackColor().CGColor
        searchBox.placeholder = "Type a company name"
        //searchBox.font = UIFont(name: "Calibri-Light", size: 11)!
        searchBox.font = UIFont.systemFontOfSize(11)
        searchBox.layer.cornerRadius = 5
        //      searchBox.hidden = false
        searchBox.addTarget(self, action: #selector(touchedSearchBox), forControlEvents: UIControlEvents.EditingDidBegin)
        searchBox.addTarget(self, action: #selector(leftSearchBox), forControlEvents: UIControlEvents.EditingDidEnd)
        
        
        
        //        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(touchedSearchBox))
        //        secondBar.addGestureRecognizer(tapGesture)
        
        let sortBy = UIButton(type: .System)
        let sortByText = NSMutableAttributedString()
        let sortByFirstPart = NSAttributedString(string: "Sort by", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 11)!, NSForegroundColorAttributeName: UIColor.rgb(88, green: 89, blue: 91)])
        let sortBySecondPart = NSAttributedString(string: " new", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 11)!, NSForegroundColorAttributeName: UIColor.rgb(228, green: 40, blue: 54)])
        sortByText.appendAttributedString(sortByFirstPart)
        sortByText.appendAttributedString(sortBySecondPart)
        let dropDownAttachment = NSTextAttachment()
        dropDownAttachment.image = UIImage(named: "icon collapse down")
        dropDownAttachment.bounds = CGRectMake(0,0,8,4)
        sortByText.appendAttributedString(NSAttributedString(attachment: dropDownAttachment))
        sortBy.setAttributedTitle(sortByText, forState: .Normal)
        
        
        secondBar.addSubview(searchBox)
        secondBar.addSubview(grayBox)
        secondBar.addSubview(searchButton)
        secondBar.addSubview(sortBy)
        secondBar.addConstraintsWithFormat("H:[v0(18)]-10-|", views: searchButton)
        secondBar.addConstraintsWithFormat("V:|-9-[v0(17)]", views: searchButton)
        secondBar.addConstraintsWithFormat("V:|-6-[v0(24)]", views: searchBox)
        secondBar.addConstraintsWithFormat("H:|-0-[v0(66)]-0-[v1]-2-[v2(37)]|", views: sortBy, searchBox, grayBox)
        secondBar.addConstraintsWithFormat("V:|-6-[v0(24)]", views: grayBox)
        secondBar.addConstraintsWithFormat("V:|-12-[v0(24)]", views: sortBy)
        
        let tappedCollectionView = UITapGestureRecognizer(target: self, action: #selector(touchedNewsFeed))
        collectionView?.addGestureRecognizer(tappedCollectionView)
        
    }
    
    func touchedNewsFeed(gesture: UITapGestureRecognizer){
        searchBox.resignFirstResponder()
    }
  
//        pageView.scrollToNextViewController()

    //When you touch the searchbox, the field changes to this color
    func touchedSearchBox(gesture: UITapGestureRecognizer) {
        searchBox.backgroundColor = UIColor.rgb(176, green: 238, blue: 237)
    }
    
    //When you leave the searchbox, the color reverts
    func leftSearchBox(gesture: UITapGestureRecognizer) {
        searchBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
    }

    //Stuff to do before any segue occurrs
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if let navigationPageViewController = segue.destinationViewController as? NavigationPageView {
            navigationPageViewController.pageViewDelegate = self
        }
    }
}


extension FeedController: NavigationPageViewControllerDelegate {
    func navigationPageViewController(navigationPageViewController: NavigationPageView,
                                      didUpdatePageCount count: Int) {
        
    }
    
    func navigationPageViewController(navigationPageViewController: NavigationPageView,
                                      didUpdatePageIndex index: Int){
        masterPageIdentificationNum = index
    }
}

class FeedCell: UICollectionViewCell {

    //Stuff that is unique to a cell
    var post: Post? {
        didSet {
            let attributedText = NSMutableAttributedString(string: "", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 14)!,
                NSForegroundColorAttributeName: UIColor.rgb(65, green: 64, blue: 66)])
            if let name = post?.name {
                attributedText.appendAttributedString(NSAttributedString(string: name, attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 14)!,
                    NSForegroundColorAttributeName: UIColor.rgb(65, green: 64, blue: 66)]))
                }
                let timeSincePost = 38
                let timeSincePostMessage = "\(timeSincePost)m ago"
                attributedText.appendAttributedString(NSAttributedString(string: "  \(timeSincePostMessage)", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 8)!,
                NSForegroundColorAttributeName: UIColor.rgb(88, green: 89, blue: 91)]))
            
            if let status = post?.statusText{
                statusText.text = status
            }
            
            if let profileImage = post?.profilePic{
                //profileImageView.setImage(ResizeImage(profileImage, targetSize: CGSizeMake(40, 40)) , forState: .Normal)
                profileImageView.setImage(profileImage, forState: .Normal)
            }
           
            
                /*let attachment = NSTextAttachment()
                 attachment.image = UIImage(named: "")
                 attachment.bounds = CGRectMake(0,-2,12,12)
                 attributedText.appendAttributedString(NSAttributedString(attachment: attachment))
                 */ //How to add an image to the end of the label
                
                nameLabel.attributedText = attributedText
    
            
        }
        
    }
  
    
    
    
    override init(frame: CGRect){
        super.init(frame: frame)
        
        setupViews()
    }
    
    //Prevents stupid xcode warning/error
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //Name of the poster, actual text of label is set above
    let nameLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 2
        return label
    }()
    
    //Profile picture of poster, actual image of button is set above
    var profileImageView: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 5.0
        button.layer.masksToBounds = true
        return button
    }()
    
    
    // General Information of poster, actual text is set above
    let statusText: UITextView = {
        let textView = UITextView()
        textView.font = UIFont(name: "Calibri-Light", size: 11)!
        //textView.font = UIFont.systemFontOfSize(11)
        textView.textColor = UIColor.rgb(88, green: 89, blue: 91)
        textView.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        //textView.backgroundColor = UIColor.redColor()
        textView.editable = false
        textView.scrollEnabled = false
        return textView
    }()
    
    
    
    //Button to add event
    let addEventViewButton: UIButton = {

        let view = UIView()
        view.frame = CGRect(x: 0, y: 0, width: 150, height: 150)
        
        let button = UIButton()
        button.setImage(UIImage(named:"icon add")! , forState: .Normal)
        
        let label = UILabel()
        label.text = "Add Event"
        label.font = UIFont(name: "Calibri-Light", size: 5)!
        label.textColor = UIColor.rgb(88, green: 89, blue: 91)
        //label.backgroundColor = UIColor.whiteColor()
        
        
        view.addSubview(button)
        view.addSubview(label)
        
        view.addConstraintsWithFormat("V:|[v0(20)]-3-[v1]", views: button, label)
        view.addConstraintsWithFormat("H:|[v0(20)]|", views: button)
        view.addConstraintsWithFormat("H:|[v0(22)]|", views: label)
        let viewButton = UIButton()
        viewButton.addSubview(view)
        viewButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        //viewButton.backgroundColor = UIColor.whiteColor()
        return viewButton
    }()
    
    //setting the view of each cell
    func setupViews() {
        backgroundColor = UIColor.whiteColor()
        
        addSubview(statusText)
        addSubview(nameLabel)
        addSubview(profileImageView)
        addSubview(addEventViewButton)
        
        //addSubview(dropDownImageButton)
        
        addConstraintsWithFormat("H:|-8-[v0(44)]-8-[v1][v2(23)]-5-|", views: profileImageView, nameLabel, addEventViewButton)
        
        addConstraintsWithFormat("H:|-8-[v0]-2-[v1][v2]-10-|", views: profileImageView, statusText, addEventViewButton)
        addConstraintsWithFormat("V:|-15-[v0]|", views: statusText)
        
        addConstraintsWithFormat("V:|-15-[v0(40)]", views: addEventViewButton)
        addConstraintsWithFormat("V:|-6-[v0]", views: nameLabel)
        addConstraintsWithFormat("V:|-8-[v0(44)]", views: profileImageView)
        
    }
    
}








