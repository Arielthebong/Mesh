//
//  MasterViewController.swift
//  Mesh
//
//  Created by Daniel Ssemanda on 8/21/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import Foundation
import UIKit

var masterPageIdentificationNum = 0
let scanner = QRCodeScanner()


//Stuff for Corner Menu
var cornerMenuBool = false
var cornerQuickAccessButton = UIButton()
var dimming = UIView()
var addContactLabelPic = UIButton()
var addNearbyContactLabelPic = UIButton()
var addNearbyContactIcon = UIButton()
var scanQRCodeLabelPic = UIButton()
var scanQRCodeIcon = UIButton()
var myQRCodeLabelPic = UIButton()
var myQRCodeIcon = UIButton()

class MasterViewController: UIViewController {
    var bigRedMenuBool = false
    var wholeView = UIView()
    var clearView = UIView()
    var barNameLabel = UILabel()
    override func viewDidLoad() {
        let frame = self.view.frame
        
        wholeView = UIView(frame: CGRectMake(0, 0, frame.width, frame.height))
        view.addSubview(wholeView)
        wholeView.addSubview(pageView.view)
        
        //Creating the NavBar
        createAndAddButtonsToNavBar()
        
        //Makes bottom right corner button
        createCornerButton()
        
    }
    
    
    //Creating the NavBar
    func createAndAddButtonsToNavBar() {
        //Creating Buttons to be stored on left and right side of NavBar
        let bounds = UIScreen.mainScreen().bounds
        let width = bounds.size.width
        //        let height = bounds.size.height
        
        
        masterNavBar = UIView(frame: CGRectMake(0, 0, width, 65))
        let grayLine = UIView(frame: CGRectMake(0, 65, width, 1))
        grayLine.backgroundColor = UIColor.lightGrayColor()
        self.view.addSubview(grayLine)
        
        let leftSideView = UIView()
        leftSideView.frame = CGRectMake(0, 0, 55, 80)
        //        leftSideView.backgroundColor = UIColor.blueColor()
        
        let logoButton: UIButton = {
            let button = UIButton()
            button.setImage(navigationLogoImage, forState: .Normal)
            button.addTarget(self, action: #selector(bringOutTheBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
            button.frame = CGRectMake(0, 0, 40, 40)
            return button
        }()
        
        let collapseRight = UIImage(named: "icon collapse right")!
        
        let collapseRightButton : UIButton = {
            let button = UIButton()
            button.setImage(collapseRight, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
            button.addTarget(self, action: #selector(bringOutTheBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
            return button
        }()
        
        //        let newsFeedBarButton = UIBarButtonItem(title: "News Feed", style: UIBarButtonItemStyle.Plain, target: self, action: nil)
        //        newsFeedBarButton.tintColor = UIColor.rgb(228, green: 40, blue: 54)
        //        let font = UIFont(name: "Calibri-Light", size: 20)
        //        newsFeedBarButton.setTitleTextAttributes([NSFontAttributeName: font!], forState: UIControlState.Normal )
        barNameLabel = UILabel()
        barNameLabel.text = "News Feed"
        barNameLabel.font = UIFont(name: "Calibri-Light", size: 28)
        barNameLabel.textColor = UIColor.rgb(228, green: 40, blue: 54)
        
//        let tappingTwice = UITapGestureRecognizer(target: self, action: #selector(tappedNewsFeedLabelTwice))
//        tappingTwice.numberOfTapsRequired = 2
//        masterNavBar.addGestureRecognizer(tappingTwice)
        
//        let tappingNavBar = UITapGestureRecognizer(target: self, action: #selector(removeBigRedMenu2))
//        masterNavBar.addGestureRecognizer(tappingNavBar)
        
        leftSideView.addSubview(logoButton)
        leftSideView.addSubview(collapseRightButton)
        leftSideView.addSubview(barNameLabel)
        leftSideView.addConstraintsWithFormat("H:|[v0(40)]-0-[v1(8)]-7-[v2]", views: logoButton, collapseRightButton, barNameLabel)
        leftSideView.addConstraintsWithFormat("V:|-19-[v0(40)]", views: logoButton)
        leftSideView.addConstraintsWithFormat("V:|-44-[v0(15)]", views: collapseRightButton)
        leftSideView.addConstraintsWithFormat("V:|-28-[v0]", views: barNameLabel)
        
        //        let leftSideButtons = UIBarButtonItem(customView: leftSideView)
        
        
        masterNavBar.addSubview(leftSideView)
        
        //        navigationItem.leftBarButtonItems = [ leftSideButtons, newsFeedBarButton]
        
        
        
        let rightSideView = UIView()
        rightSideView.frame = CGRectMake(0, 0, 100, 80)
        
        
        let reminderButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(named:"icon reminder")!, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
            //            button.addTarget(self, action: #selector(reminderButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
            return button
        }()
        
        let contactButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(named:"icon contact")!, forState: .Normal)
            button.frame = CGRectMake(0, 0, 40, 40)
            //button.addTarget(<#T##target: AnyObject?##AnyObject?#>, action: <#T##Selector#>, forControlEvents: <#T##UIControlEvents#>)
            return button
        }()
        
        let contactNumberBubble = UIImageView(image: UIImage(named: "icon number bubble"))
        
        
        
        let reminderNumberBubble = UIView()
        reminderNumberBubble.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        
        
        //        rightSideView.backgroundColor = UIColor.blueColor()
        
        let contactNotificationsLabel = UILabel()
        contactNotificationsLabel.text = "\(contactNumberOfNotifications)"
        contactNotificationsLabel.textColor = UIColor.whiteColor()
        contactNotificationsLabel.font = UIFont.boldSystemFontOfSize(10)
        
        let reminderNotificationsLabel = UILabel()
        reminderNotificationsLabel.text = "\(reminderNumberOfNotifications)"
        reminderNotificationsLabel.textColor = UIColor.whiteColor()
        reminderNotificationsLabel.font = UIFont.boldSystemFontOfSize(10)
        
        rightSideView.addSubview(reminderButton)
        rightSideView.addSubview(contactButton)
        rightSideView.addSubview(contactNumberBubble)
        rightSideView.addSubview(contactNotificationsLabel)
        rightSideView.addSubview(reminderNotificationsLabel)
        
        rightSideView.addConstraintsWithFormat("H:[v0(40)]-20-[v1(19)]|", views: reminderButton,contactButton)
        rightSideView.addConstraintsWithFormat("V:|-29-[v0(22)]", views: reminderButton)
        rightSideView.addConstraintsWithFormat("V:|-20-[v0(35)]", views: contactButton)
        if (contactNumberOfNotifications == 0){
            contactNumberBubble.alpha = 0
            contactNotificationsLabel.alpha = 0
        }
        else if (contactNumberOfNotifications < 10) {
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNotificationsLabel)
            contactNotificationsLabel.text = " \(contactNumberOfNotifications)"
        }
        else if (contactNumberOfNotifications >= 10 && contactNumberOfNotifications < 100){
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: contactNotificationsLabel)
        }
        else if (contactNumberOfNotifications >= 100 ){
            if (contactNumberOfNotifications >= 1000){
                contactNotificationsLabel.text = "999"
            }
            rightSideView.addConstraintsWithFormat("H:[v0(20)]-10-|", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-41-[v0(20)]", views: contactNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(21)]-9-|", views: contactNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-41-[v0(20)]", views: contactNotificationsLabel)
        }
        
        
        
        if (reminderNumberOfNotifications == 0){
            reminderNumberBubble.alpha = 0
            reminderNotificationsLabel.alpha = 0
        }
        else if (reminderNumberOfNotifications < 10){
            reminderNumberBubble.layer.cornerRadius = 2.5
            rightSideView.addSubview(reminderNumberBubble)
            
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-70-|", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-69-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNotificationsLabel)
            reminderNotificationsLabel.text = " \(reminderNumberOfNotifications)"
        }
        else if (reminderNumberOfNotifications >= 10 && reminderNumberOfNotifications < 100){
            reminderNumberBubble.layer.cornerRadius = 2.5
            rightSideView.addSubview(reminderNumberBubble)
            
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-70-|", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNumberBubble)
            rightSideView.addConstraintsWithFormat("H:[v0(15)]-69-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-45-[v0(15)]", views: reminderNotificationsLabel)
        }
        else if (reminderNumberOfNotifications >= 100){
            if (reminderNumberOfNotifications >= 1000){
                reminderNotificationsLabel.text = "999"
            }
            let wholeReminderBubble = UIView()
            
            let reminderNumberBubble2 = UIView()
            let reminderNumberBubble3 = UIView()
            let reminderNumberBubble4 = UIView()
            
            reminderNumberBubble2.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            reminderNumberBubble3.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            reminderNumberBubble4.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            
            wholeReminderBubble.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            wholeReminderBubble.layer.cornerRadius = 3.0
            rightSideView.addSubview(wholeReminderBubble)
            rightSideView.bringSubviewToFront(reminderNotificationsLabel)
            
            rightSideView.addConstraintsWithFormat("H:[v0(20)]-68-|", views: wholeReminderBubble)
            rightSideView.addConstraintsWithFormat("V:|-40-[v0(20)]", views: wholeReminderBubble)
            
            
            rightSideView.addConstraintsWithFormat("H:[v0(21)]-67-|", views: reminderNotificationsLabel)
            rightSideView.addConstraintsWithFormat("V:|-40-[v0(20)]", views: reminderNotificationsLabel)
        }
        
        //        let rightSideButtons = UIBarButtonItem(customView: rightSideView)
        
        masterNavBar.addSubview(rightSideView)
        
        masterNavBar.addConstraintsWithFormat("H:|-10-[v0(55)][v1(100)]-10-|", views: leftSideView, rightSideView)
        masterNavBar.addConstraintsWithFormat("V:|[v0(80)]|", views: leftSideView)
        masterNavBar.addConstraintsWithFormat("V:|[v0(80)]|", views: rightSideView)
        
        masterNavBar.backgroundColor = UIColor.whiteColor()
        masterNavBar.userInteractionEnabled = true
        leftSideView.userInteractionEnabled = true
        rightSideView.userInteractionEnabled = true
        
        let tappedNavBarOnce = UITapGestureRecognizer(target: self, action: #selector(navBarTouched))
        let tappedNavBarTwice = UITapGestureRecognizer(target: self, action: #selector(moveNewsFeedToTop))
        tappedNavBarTwice.numberOfTapsRequired = 2
        masterNavBar.addGestureRecognizer(tappedNavBarOnce)
        masterNavBar.addGestureRecognizer(tappedNavBarTwice)
        
        wholeView.addSubview(masterNavBar)
        
        
       
        
        //        navigationItem.rightBarButtonItems = [rightSideButtons ]
        
        //Box behind NavBar to ensure correct coloring of NavBar
        //        let frame = self.view.frame
        //        let NavBarColorFixer = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, view.frame.width, 64))
        //        NavBarColorFixer.backgroundColor = UIColor.whiteColor()
        //        self.view.addSubview(NavBarColorFixer)
    }
    
    //Bringing out the Big Red Menu
    func bringOutTheBigRedMenu(){
        let frame = self.view.frame
        bigRedMenuBool = true
        
        clearView = UIView(frame: CGRectMake(0, 0, frame.width, frame.height))
        clearView.backgroundColor = UIColor.clearColor()
        let tappedClearView = UITapGestureRecognizer(target: self, action: #selector(clearViewTapped))
        clearView.addGestureRecognizer(tappedClearView)
        view.addSubview(clearView)
       
        bigRedMenu = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, ceil(self.view.frame.width * (2/3))  , frame.height))
        bigRedMenu.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        
        let slideInFromLeftTransition = CATransition()
        slideInFromLeftTransition.type = kCATransitionPush
        slideInFromLeftTransition.subtype = kCATransitionFromLeft
        slideInFromLeftTransition.duration = 0.3
        slideInFromLeftTransition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        slideInFromLeftTransition.fillMode = kCAFillModeRemoved
        bigRedMenu.layer.addAnimation(slideInFromLeftTransition, forKey: "slideInFromLeftTransition")
        
        let  whiteCollapseLeft = UIButton(type: .Custom)
        whiteCollapseLeft.setImage(UIImage(named: "icon collapse left white"), forState: .Normal)
        whiteCollapseLeft.addTarget(self , action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        
        let navigationButton = UIButton(type: .Custom)
        navigationButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        let stringFormat = NSMutableAttributedString(string: "Navigation", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 28)!, NSForegroundColorAttributeName: UIColor.whiteColor()])
        navigationButton.setAttributedTitle(stringFormat, forState: .Normal)
        navigationButton.addTarget(self , action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        //        self.navigationController.addChildViewController(bigRedCollectionView) //Seems to be unnecessary
        //        bigRedCollectionView.didMoveToParentViewController(masterNavBar)
        
        let settingsButton = UIButton(type: .Custom)
        settingsButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        let stringFormat2 = NSMutableAttributedString(string: "Settings", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 28)!, NSForegroundColorAttributeName: UIColor.whiteColor()])
        settingsButton.setAttributedTitle(stringFormat2, forState: .Normal)
//        settingsButton.addTarget(self, action: #selector(settingsClicked), forControlEvents: UIControlEvents.TouchUpInside)
        
        let settingsLogo = UIButton(type: .Custom)
        settingsLogo.setImage(UIImage(named: "icon sidebar settings"), forState: .Normal)
        //        settingsLogo.addTarget(<#T##target: AnyObject?##AnyObject?#>, action: <#T##Selector#>, forControlEvents: <#T##UIControlEvents#>)
        
        let whiteLogo = UIButton(type: .Custom)
        whiteLogo.setImage( UIImage(named: "mesh logo small white"), forState: .Normal)
        whiteLogo.addTarget(self, action: #selector(removeBigRedMenu), forControlEvents: UIControlEvents.TouchUpInside)
        bigRedMenu.addSubview(whiteLogo)
        bigRedMenu.addSubview(whiteCollapseLeft)
        bigRedMenu.addSubview(navigationButton)
        bigRedMenu.addSubview(settingsLogo)
        bigRedMenu.addSubview(settingsButton)
        bigRedMenu.addSubview(bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|-15-[v0(40)][v1(8)]-8-[v2]", views: whiteLogo, whiteCollapseLeft, navigationButton)
        bigRedMenu.addConstraintsWithFormat("V:|-19-[v0(40)]", views: whiteLogo)
        bigRedMenu.addConstraintsWithFormat("V:|-44-[v0(15)]", views: whiteCollapseLeft)
        bigRedMenu.addConstraintsWithFormat("V:|-23-[v0(40)]", views: navigationButton)
        bigRedMenu.addConstraintsWithFormat("V:|-70-[v0]-70-|", views: bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|[v0]|", views: bigRedCollectionView.view)
        bigRedMenu.addConstraintsWithFormat("H:|-20-[v0(30)]-8-[v1]", views: settingsLogo, settingsButton)
        bigRedMenu.addConstraintsWithFormat("V:[v0(30)]-15-|", views: settingsLogo)
        bigRedMenu.addConstraintsWithFormat("V:[v0]-10-|", views: settingsButton)
        
        let swipeLeftOnMenu = UISwipeGestureRecognizer(target: self, action: #selector(swipedOnMenu))
        swipeLeftOnMenu.direction = UISwipeGestureRecognizerDirection.Left
        bigRedMenu.addGestureRecognizer(swipeLeftOnMenu)
        
        view.addSubview(bigRedMenu)
        view.bringSubviewToFront(bigRedMenu)
        
        
    }
    
    func swipedOnMenu(gesture: UISwipeGestureRecognizer){
        removeBigRedMenu()
    }
    
    func navBarTouched(gesture: UITapGestureRecognizer) {
        if (masterPageIdentificationNum == 0){
           searchBox.resignFirstResponder()
        }
        if (masterPageIdentificationNum == 1){
            profileView.searchBox.resignFirstResponder()
        }
    }
    
    func moveNewsFeedToTop(gesture: UITapGestureRecognizer) {
        if (masterPageIdentificationNum == 0){
            newsFeedView.collectionView?.setContentOffset(CGPointMake(0, 0), animated: true)
        }
    }
    
    //When area behind RedMenu is touched
    func clearViewTapped(gesture: UITapGestureRecognizer) {
        removeBigRedMenu()
    }
    
    //When the Big Red Menu needs to go away
    func removeBigRedMenu(){
        bigRedMenuBool = false
        clearView.removeFromSuperview()
        let menuWidth = bigRedMenu.bounds.width
        
        let offstageLeft = CGAffineTransformMakeTranslation( -menuWidth, 0)
        UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            bigRedMenu.transform = offstageLeft
            }, completion: {(finished:Bool) in
                self.finishOffBigRedMenu()
        })
        
    }
    
    func finishOffBigRedMenu() {
        bigRedMenu.removeFromSuperview()
    }
    
    //Makes bottom right corner button
    func createCornerButton(){
        cornerQuickAccessButton = UIButton(frame: CGRectMake(view.frame.width - 75, view.frame.height - 75, 65, 65))
        cornerQuickAccessButton.setImage(UIImage(named: "icon contact add"), forState: .Normal)
        cornerQuickAccessButton.addTarget(self, action: #selector(bringCornerMenu), forControlEvents: .TouchUpInside)
        view.addSubview(cornerQuickAccessButton)
        
    }
    
    //When you hit the lower right hand corner button
    func bringCornerMenu() {
        if (!cornerMenuBool){
            cornerMenuBool = true
            
            UIView.animateWithDuration(0.3, animations: {
                cornerQuickAccessButton.alpha = 1
            })
            
            let frame = self.view.frame
            dimming = UIView(frame: CGRectMake(frame.origin.x, frame.origin.y, view.frame.width, view.frame.height))
            dimming.backgroundColor = UIColor.whiteColor()
            dimming.alpha = 0.5
            
            let slideInFromBottomTransition = CATransition()
            slideInFromBottomTransition.type = kCATransitionPush
            slideInFromBottomTransition.subtype = kCATransitionFromBottom
            slideInFromBottomTransition.duration = 0.3
            slideInFromBottomTransition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
            slideInFromBottomTransition.fillMode = kCAFillModeRemoved
            
            addContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 183, view.frame.height - 53, 103, 25))
            addContactLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            addContactLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            addContactLabelPic.addTarget(self, action: #selector(addContactAction), forControlEvents: .TouchUpInside)
            
            addNearbyContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 113, 103, 25))
            addNearbyContactLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            addNearbyContactLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            addNearbyContactLabelPic.addTarget(self, action: #selector(addNearbyAction), forControlEvents: .TouchUpInside)
            
            addNearbyContactIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 125, 50, 50))
            addNearbyContactIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            addNearbyContactIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            addNearbyContactIcon.addTarget(self, action: #selector(addNearbyAction), forControlEvents: .TouchUpInside)
            
            scanQRCodeLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 163, 103, 25))
            scanQRCodeLabelPic.setImage( UIImage(named: "scan qr bubble text"), forState: .Normal)
            scanQRCodeLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            scanQRCodeLabelPic.addTarget(self, action: #selector(scanQRCodeAction), forControlEvents: .TouchUpInside)
            
            scanQRCodeIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 175, 50, 50))
            scanQRCodeIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            scanQRCodeIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            scanQRCodeIcon.addTarget(self, action: #selector(scanQRCodeAction), forControlEvents: .TouchUpInside)
            
            myQRCodeLabelPic = UIButton(frame: CGRectMake(view.frame.width - 175, view.frame.height - 213, 103, 25))
            myQRCodeLabelPic.setImage( UIImage(named: "Add contact bubble text button"), forState: .Normal)
            myQRCodeLabelPic.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            myQRCodeLabelPic.addTarget(self, action: #selector(myQRCodeAction), forControlEvents: .TouchUpInside)
            
            myQRCodeIcon = UIButton(frame: CGRectMake(view.frame.width - 65, view.frame.height - 225, 50, 50))
            myQRCodeIcon.setImage( UIImage(named: "icon qr bubble"), forState: .Normal)
            myQRCodeIcon.layer.addAnimation(slideInFromBottomTransition, forKey: "slideInFromBottomTransition")
            myQRCodeIcon.addTarget(self, action: #selector(myQRCodeAction), forControlEvents: .TouchUpInside)
            
            cornerQuickAccessButton.removeFromSuperview()
            view.addSubview(dimming)
            view.addSubview(cornerQuickAccessButton)
            view.addSubview(addContactLabelPic)
            view.addSubview(addNearbyContactLabelPic)
            view.addSubview(addNearbyContactIcon)
            view.addSubview(scanQRCodeLabelPic)
            view.addSubview(scanQRCodeIcon)
            view.addSubview(myQRCodeLabelPic)
            view.addSubview(myQRCodeIcon)
            cornerQuickAccessButton.alpha = 1
            
            
            //
            //            addContactLabelPic = UIButton(frame: CGRectMake(view.frame.width - 183, view.frame.height + 1, 103, 25))
            //        UIView.animateWithDuration(0.3, delay: 0.1, options: UIViewAnimationOptions.CurveEaseIn , animations: {
            //            addContactLabelPic = UIButton(frame: CGRectMake(self.view.frame.width - 183, self.view.frame.height - 53, 103, 25))
            //        }, completion: nil)
            //
            
            let tapDimmingView = UITapGestureRecognizer(target: self, action: #selector(removeCornerMenu))
            dimming.addGestureRecognizer(tapDimmingView)
            
        }
        else{
//           addContactAction()
            removeCornerMenu()
        }
        
    }
    
    //when "Add contact" is selected from corner menu
    func addContactAction() {
        
    }
    
    //when "Add nearby" is selected from corner menu
    func addNearbyAction() {
        
    }
    
    //when "Scan QR Code" is selected from corner menu
    func scanQRCodeAction() {
        self.presentViewController(scanner, animated: true, completion: nil)
    }
    
    //when "My QR Code" is selected from corner menu
    func myQRCodeAction() {
        
    }
    
    
    
    //Used to remove corner menu
    func removeCornerMenu(){
        dimming.removeFromSuperview()
        addContactLabelPic.removeFromSuperview()
        addNearbyContactLabelPic.removeFromSuperview()
        addNearbyContactIcon.removeFromSuperview()
        scanQRCodeLabelPic.removeFromSuperview()
        scanQRCodeIcon.removeFromSuperview()
        myQRCodeLabelPic.removeFromSuperview()
        myQRCodeIcon.removeFromSuperview()
        cornerMenuBool = false
        if (masterPageIdentificationNum == 1){
                cornerQuickAccessButton.alpha = 0.5
        }
    }
    

}