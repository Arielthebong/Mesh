//
//  MyProfile.swift
//  Mesh
//
//  Created by Daniel Ssemanda on 8/14/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import Foundation



class MyProfileView: UIViewController{
    
    //For handling the tabs and their look
    var isMyInfoPageOpen = true
    let myInfoTab = UIButton()
    let myInfoTabSelectedString = NSMutableAttributedString()
    let myInfoTabString = NSMutableAttributedString()
    let myDocumentsTab = UIButton()
    let myDocumentsTabSelectedString = NSMutableAttributedString()
    let myDocumentsTabString = NSMutableAttributedString()
    var myDocumentsSuperView = UIView()
    
    //For SearchBar in myDocuments Section
//    var bigRedMenuBool = false
    var secondBar = UIView()
    let searchBox = TextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.whiteColor()
//        let frame = self.view.frame
       
        //Creates My Info and My Documents Tabs
        createTabs()
        
        //Creating the NavBar
        makeBioSection()
 
        //Creates Phone, Email, Fax, etc. sections
        makeOtherSections()
        
        //Create the view for when my Documents is touched
        createMyDocumentsSuperView()
        

        view.bringSubviewToFront(cornerQuickAccessButton)
//        createAndAddButtonsToNavBar()
    }
    
    override func viewDidAppear(animated: Bool) {
        masterPageIdentificationNum = 1
        let cell0 = bigRedCollectionView.collectionView!.cellForItemAtIndexPath(NSIndexPath(forRow: 0, inSection: 0))
        cell0?.contentView.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        let cell1 = bigRedCollectionView.collectionView!.cellForItemAtIndexPath(NSIndexPath(forRow: 1, inSection: 0))
        cell1?.contentView.backgroundColor = UIColor.lightGrayColor()
        
        let cell2 = bigRedCollectionView.collectionView!.cellForItemAtIndexPath(NSIndexPath(forRow: 2, inSection: 0))
        cell2?.contentView.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        let cell3 = bigRedCollectionView.collectionView!.cellForItemAtIndexPath(NSIndexPath(forRow: 3, inSection: 0))
        cell3?.contentView.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        
        masterView.barNameLabel.text = "My Profile"
        
        UIView.animateWithDuration(0.3, animations: {
           cornerQuickAccessButton.alpha = 0.5
        })
        
    }
    
    func removeKeyboard() {
       searchBox.resignFirstResponder()
    }
    
    //Create the view for when my Documents is touched
    func createMyDocumentsSuperView() {
        let frame = self.view.frame
        myDocumentsSuperView = UIView(frame: CGRectMake(0, 108, frame.width, frame.height - 108))
        myDocumentsSuperView.backgroundColor = UIColor.whiteColor()
        let tappingDocumentsSuperview = UITapGestureRecognizer(target: self, action: #selector(removeKeyboard))
        myDocumentsSuperView.addGestureRecognizer(tappingDocumentsSuperview)
        
        secondBar = UIView(frame: CGRectMake(0, 0, view.frame.width, 36))
        secondBar.backgroundColor = UIColor.whiteColor()
        
        let grayBox = UIView()
        grayBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        
        let searchButton = UIButton()
        searchButton.setImage(UIImage(named:"icon search"), forState: .Normal)
        //        searchButton.addTarget(self, action: #selector(makeSegueChange), forControlEvents: UIControlEvents.TouchUpInside)
        
        
        searchBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        //      searchBox.backgroundColor = UIColor.rgb(176, green: 238, blue: 237)
        searchBox.layer.borderWidth = 1.0
        searchBox.layer.borderColor = UIColor.blackColor().CGColor
        searchBox.placeholder = "Type a company name"
        //searchBox.font = UIFont(name: "Calibri-Light", size: 11)!
        searchBox.font = UIFont.systemFontOfSize(11)
        searchBox.layer.cornerRadius = 5
        //      searchBox.hidden = false
        searchBox.addTarget(self, action: #selector(touchedSearchBox), forControlEvents: UIControlEvents.EditingDidBegin)
        searchBox.addTarget(self, action: #selector(leftSearchBox), forControlEvents: UIControlEvents.EditingDidEnd)
        
        
        
        //        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(touchedSearchBox))
        //        secondBar.addGestureRecognizer(tapGesture)
        
        let sortBy = UIButton(type: .System)
        let sortByText = NSMutableAttributedString()
        let sortByFirstPart = NSAttributedString(string: "Sort by", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 11)!, NSForegroundColorAttributeName: UIColor.rgb(88, green: 89, blue: 91)])
        let sortBySecondPart = NSAttributedString(string: " date added", attributes: [NSFontAttributeName: UIFont(name: "Calibri-Light", size: 11)!, NSForegroundColorAttributeName: UIColor.rgb(228, green: 40, blue: 54)])
        sortByText.appendAttributedString(sortByFirstPart)
        sortByText.appendAttributedString(sortBySecondPart)
        let dropDownAttachment = NSTextAttachment()
        dropDownAttachment.image = UIImage(named: "icon collapse down")
        dropDownAttachment.bounds = CGRectMake(0,0,8,4)
        sortByText.appendAttributedString(NSAttributedString(attachment: dropDownAttachment))
        sortBy.setAttributedTitle(sortByText, forState: .Normal)
        
        
        secondBar.addSubview(searchBox)
        secondBar.addSubview(grayBox)
        secondBar.addSubview(searchButton)
        secondBar.addSubview(sortBy)
        secondBar.addConstraintsWithFormat("H:[v0(18)]-10-|", views: searchButton)
        secondBar.addConstraintsWithFormat("V:|-9-[v0(17)]", views: searchButton)
        secondBar.addConstraintsWithFormat("V:|-6-[v0(24)]", views: searchBox)
        secondBar.addConstraintsWithFormat("H:|-0-[v0(102)]-0-[v1]-2-[v2(37)]|", views: sortBy, searchBox, grayBox)
        secondBar.addConstraintsWithFormat("V:|-6-[v0(24)]", views: grayBox)
        secondBar.addConstraintsWithFormat("V:|-12-[v0(24)]", views: sortBy)
        myDocumentsSuperView.addSubview(secondBar)
    }
    
    //Creates My Info and My Documents Tabs
    func createTabs() {
        let frame = self.view.frame
        
        
        myInfoTab.frame = CGRectMake(0, 65, ceil(frame.width / 2), 40)
        myInfoTab.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        myInfoTab.addTarget(self, action: #selector(myInfoTabClicked), forControlEvents: UIControlEvents.TouchUpInside)
        
        let rightFacingCollapseIcon = NSTextAttachment()
        rightFacingCollapseIcon.image = imageResize(UIImage(named: "icon collapse right white")!, sizeChange: CGSize(width: 10, height: 10))
        
        let leftFacingCollapseIcon = NSTextAttachment()
        leftFacingCollapseIcon.image = imageResize(UIImage(named: "icon collapse left white")!, sizeChange: CGSize(width: 10, height: 10))
        
        let rightAttachmentString = NSAttributedString(attachment: rightFacingCollapseIcon)
        let leftAttachmentString = NSAttributedString(attachment: leftFacingCollapseIcon)
        
        
        let myInfoStringText = NSAttributedString(string: "  My Info  ", attributes: [NSForegroundColorAttributeName: UIColor.whiteColor()])
        myInfoTabSelectedString.appendAttributedString(rightAttachmentString)
        myInfoTabSelectedString.appendAttributedString(myInfoStringText)
        myInfoTabSelectedString.appendAttributedString(leftAttachmentString)
        
        myInfoTabString.appendAttributedString(myInfoStringText)
        myInfoTab.setAttributedTitle(myInfoTabSelectedString, forState: .Normal)
        

    
        self.view.addSubview(myInfoTab)
        
        
        
        myDocumentsTab.frame = CGRectMake(ceil(frame.width / 2) + 3, 65, frame.width - ceil(frame.width / 2) - 3 , 40)
        myDocumentsTab.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        myDocumentsTab.addTarget(self, action: #selector(myDocumentsTabClicked), forControlEvents: UIControlEvents.TouchUpInside)
        
        let myDocumentsStringText = NSAttributedString(string: " My Documents ", attributes: [NSForegroundColorAttributeName: UIColor.whiteColor()])
        
        myDocumentsTabSelectedString.appendAttributedString(rightAttachmentString)
        myDocumentsTabSelectedString.appendAttributedString(myDocumentsStringText)
        myDocumentsTabSelectedString.appendAttributedString(leftAttachmentString)
        
        myDocumentsTabString.appendAttributedString(myDocumentsStringText)
        
        myDocumentsTab.setAttributedTitle(myDocumentsTabString, forState: .Normal)
        self.view.addSubview(myDocumentsTab)
    }
    
    //When you touch the searchbox, the field changes to this color
    func touchedSearchBox(gesture: UITapGestureRecognizer) {
        searchBox.backgroundColor = UIColor.rgb(176, green: 238, blue: 237)
    }
    
    //When you leave the searchbox, the color reverts
    func leftSearchBox(gesture: UITapGestureRecognizer) {
        searchBox.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
    }

    
    func myDocumentsTabClicked() {
        if (isMyInfoPageOpen) {
           myDocumentsTab.setAttributedTitle(myDocumentsTabSelectedString, forState: .Normal)
           myInfoTab.setAttributedTitle(myInfoTabString, forState: .Normal)
           view.addSubview(myDocumentsSuperView)
           view.bringSubviewToFront(cornerQuickAccessButton)
           isMyInfoPageOpen = false
        }
    }
    
    func myInfoTabClicked() {
        if(!isMyInfoPageOpen){
            myDocumentsTab.setAttributedTitle(myDocumentsTabString, forState: .Normal)
            myInfoTab.setAttributedTitle(myInfoTabSelectedString, forState: .Normal)
            myDocumentsSuperView.removeFromSuperview()
            isMyInfoPageOpen = true
        }
    }
    
    
    //Creates first biographical info section
    func makeBioSection() {
        let frame = self.view.frame
        let myInfoView = UIView(frame: CGRectMake(0, 108, frame.width, 120))
        myInfoView.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        self.view.addSubview(myInfoView)
        
        let myProfilePic = UIImageView()
        myProfilePic.backgroundColor = UIColor.whiteColor()
        
        let myNameLabel = UILabel()
        myNameLabel.text = "John Smith"
        myNameLabel.font = UIFont(name: "Calibri-Light", size: 34)
        myNameLabel.textColor = UIColor.whiteColor()
        
        let myCompanyLabel = UILabel()
        myCompanyLabel.text = "Yale"
        myCompanyLabel.font = UIFont(name: "Calibri-Light", size: 18)
        myCompanyLabel.textColor = UIColor.whiteColor()
        
        let myPositionLabel = UILabel()
        myPositionLabel.text = "Marketing Management"
        myPositionLabel.font = UIFont(name: "Calibri-Light", size: 14)
        myPositionLabel.textColor = UIColor.whiteColor()
        
        let editButton = UIButton()
        let editLabel = UILabel()
        editLabel.text = "Edit"
        editLabel.textColor = UIColor.whiteColor()
        editLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let editIcon = UIImageView()
        editIcon.image = UIImage(named: "icon sidebar network")
        editButton.addSubview(editLabel)
        editButton.addSubview(editIcon)
        editButton.addConstraintsWithFormat("H:[v0(40)][v1(25)]|", views: editLabel, editIcon)
        editButton.addConstraintsWithFormat("V:[v0(20)]|", views: editLabel)
        editButton.addConstraintsWithFormat("V:|[v0(25)]|", views: editIcon)
        
        
        
        myInfoView.addSubview(myProfilePic)
        myInfoView.addSubview(myNameLabel)
        myInfoView.addSubview(myCompanyLabel)
        myInfoView.addSubview(myPositionLabel)
        myInfoView.addSubview(editButton)
        myInfoView.addConstraintsWithFormat("H:|-10-[v0(100)]-5-[v1]|", views: myProfilePic, myNameLabel)
        myInfoView.addConstraintsWithFormat("V:|-10-[v0(100)]", views: myProfilePic)
        myInfoView.addConstraintsWithFormat("V:|-10-[v0]", views: myNameLabel)
        myInfoView.addConstraintsWithFormat("V:[v0]-5-[v1]-10-|", views: myCompanyLabel, myPositionLabel)
        myInfoView.addConstraintsWithFormat("H:|-10-[v0(100)]-5-[v1]", views: myProfilePic, myCompanyLabel)
        myInfoView.addConstraintsWithFormat("H:|-10-[v0(100)]-5-[v1]", views: myProfilePic, myPositionLabel)
        myInfoView.addConstraintsWithFormat("H:[v0(55)]|", views: editButton)
        myInfoView.addConstraintsWithFormat("V:[v0(25)]-10-|", views: editButton)
    }
    
    //Creates Phone, Email, Fax, etc. sections
    func makeOtherSections(){
        let frame = self.view.frame
        let sizeCalculation = floor((frame.height - 318) / 4)
        
        let phoneSection = UIView(frame: CGRectMake(0, 238, frame.width, sizeCalculation + 20))
        phoneSection.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        let phoneIcon = UIImageView()
        phoneIcon.image = UIImage(named: "icon number bubble")
        let phoneLabel = UILabel()
        phoneLabel.text = "Phone"
        phoneLabel.textColor = UIColor.rgb(65, green: 64, blue: 66)
        phoneLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let mobilePhoneNumber = UILabel()
        mobilePhoneNumber.text = "(555) 987-1234"
        mobilePhoneNumber.textColor = UIColor.rgb(65, green: 64, blue: 66)
        mobilePhoneNumber.font = UIFont(name: "Calibri-Light", size: 18)
        let mobilePhoneLabel = UILabel()
        mobilePhoneLabel.text = "Mobile"
        mobilePhoneLabel.textColor = UIColor.rgb(147, green: 149, blue: 152)
        mobilePhoneLabel.font = UIFont(name: "Calibri-Light", size: 14)
        let workPhoneNumber = UILabel()
        workPhoneNumber.text = "(444) 569-1234"
        workPhoneNumber.textColor = UIColor.rgb(65, green: 64, blue: 66)
        workPhoneNumber.font = UIFont(name: "Calibri-Light", size: 18)
        let workPhoneLabel = UILabel()
        workPhoneLabel.text = "Work"
        workPhoneLabel.textColor = UIColor.rgb(147, green: 149, blue: 152)
        workPhoneLabel.font = UIFont(name: "Calibri-Light", size: 14)
        
        
        phoneSection.addSubview(phoneIcon)
        phoneSection.addSubview(phoneLabel)
        phoneSection.addSubview(mobilePhoneNumber)
        phoneSection.addSubview(mobilePhoneLabel)
        phoneSection.addSubview(workPhoneNumber)
        phoneSection.addSubview(workPhoneLabel)
        phoneSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: phoneIcon, phoneLabel)
        phoneSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1][v2]", views: phoneLabel, mobilePhoneNumber, mobilePhoneLabel)
        phoneSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1][v2]", views: phoneLabel, workPhoneNumber, workPhoneLabel)
        phoneSection.addConstraintsWithFormat("V:|-10-[v0(25)]", views: phoneIcon)
        phoneSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]-10-[v2]", views: phoneIcon, mobilePhoneNumber, workPhoneNumber)
        phoneSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]-10-[v2]", views: phoneIcon, mobilePhoneNumber, workPhoneLabel)
        phoneSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: phoneIcon, mobilePhoneLabel)
        
        
        
        self.view.addSubview(phoneSection)
        
        let emailSectionYPos = 238 + sizeCalculation + 30
        let emailSection = UIView(frame: CGRectMake(0, emailSectionYPos, frame.width, sizeCalculation + 20))
        emailSection.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        let emailIcon = UIImageView()
        emailIcon.image = UIImage(named: "icon number bubble")
        let emailLabel = UILabel()
        emailLabel.text = "Email"
        emailLabel.textColor = UIColor.rgb(65, green: 64, blue: 66)
        emailLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let workEmailText = UILabel()
        workEmailText.text = "jsmith@yale.edu"
        workEmailText.textColor = UIColor.rgb(65, green: 64, blue: 66)
        workEmailText.font = UIFont(name: "Calibri-Light", size: 18)
        let workEmailLabel = UILabel()
        workEmailLabel.text = "Work"
        workEmailLabel.textColor = UIColor.rgb(147, green: 149, blue: 152)
        workEmailLabel.font = UIFont(name: "Calibri-Light", size: 14)
        let personalEmailText = UILabel()
        personalEmailText.text = "jsmith12@gmail.com"
        personalEmailText.textColor = UIColor.rgb(65, green: 64, blue: 66)
        personalEmailText.font = UIFont(name: "Calibri-Light", size: 18)
        let personalEmailLabel = UILabel()
        personalEmailLabel.text = "Work"
        personalEmailLabel.textColor = UIColor.rgb(147, green: 149, blue: 152)
        personalEmailLabel.font = UIFont(name: "Calibri-Light", size: 14)
        
        
        
        emailSection.addSubview(emailIcon)
        emailSection.addSubview(emailLabel)
        emailSection.addSubview(workEmailText)
        emailSection.addSubview(workEmailLabel)
        emailSection.addSubview(personalEmailText)
        emailSection.addSubview(personalEmailLabel)
        emailSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: emailIcon, emailLabel)
        emailSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1][v2]", views: emailLabel, workEmailText, workEmailLabel)
        emailSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1][v2]", views: emailLabel, personalEmailText, personalEmailLabel)
        emailSection.addConstraintsWithFormat("V:|-10-[v0(25)]", views: emailIcon)
        emailSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]-10-[v2]", views: emailIcon, workEmailText, personalEmailText)
        emailSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]-10-[v2]", views: emailIcon, workEmailText, personalEmailLabel)
        emailSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: emailIcon, workEmailLabel)
        
        self.view.addSubview(emailSection)
        
        
        
        let faxSectionYPos = emailSectionYPos + sizeCalculation + 30
        let faxSection = UIView(frame: CGRectMake(0, faxSectionYPos, frame.width, sizeCalculation))
        faxSection.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        let faxIcon = UIImageView()
        faxIcon.image = UIImage(named: "icon number bubble")
        let faxLabel = UILabel()
        faxLabel.text = "Fax"
        faxLabel.textColor = UIColor.rgb(65, green: 64, blue: 66)
        faxLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let faxNumberText = UILabel()
        faxNumberText.text = "+1-212-9876543"
        faxNumberText.textColor = UIColor.rgb(65, green: 64, blue: 66)
        faxNumberText.font = UIFont(name: "Calibri-Light", size: 18)
        
        faxSection.addSubview(faxIcon)
        faxSection.addSubview(faxLabel)
        faxSection.addSubview(faxNumberText)
        faxSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: faxIcon, faxLabel)
        faxSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1]", views: faxLabel, faxNumberText)
        faxSection.addConstraintsWithFormat("V:|-10-[v0(25)]", views: faxIcon)
        faxSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: faxIcon, faxNumberText)
        
        self.view.addSubview(faxSection)
        
        
        
        let officeSectionYPos = faxSectionYPos + sizeCalculation + 10
        let officeSection = UIView(frame: CGRectMake(0, officeSectionYPos, frame.width, sizeCalculation))
        officeSection.backgroundColor = UIColor.rgb(230, green: 231, blue: 232)
        let officeIcon = UIImageView()
        officeIcon.image = UIImage(named: "icon number bubble")
        let officeLabel = UILabel()
        officeLabel.text = "Office"
        officeLabel.textColor = UIColor.rgb(65, green: 64, blue: 66)
        officeLabel.font = UIFont(name: "Calibri-Light", size: 20)
        let officeLocation = UILabel()
        officeLocation.text = "321 Baker Street NY, NY 02345"
        officeLocation.textColor = UIColor.rgb(65, green: 64, blue: 66)
        officeLocation.font = UIFont(name: "Calibri-Light", size: 18)
        
        officeSection.addSubview(officeIcon)
        officeSection.addSubview(officeLabel)
        officeSection.addSubview(officeLocation)
        officeSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: officeIcon, officeLabel)
        officeSection.addConstraintsWithFormat("V:|-10-[v0(25)][v1]", views: officeLabel, officeLocation)
        officeSection.addConstraintsWithFormat("V:|-10-[v0(25)]", views: officeIcon)
        officeSection.addConstraintsWithFormat("H:|-10-[v0(25)]-10-[v1]", views: officeIcon, officeLocation)
        
        self.view.addSubview(officeSection)
 
    }
    
    
    //Stuff to do before any segue occurrs
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if let navigationPageViewController = segue.destinationViewController as? NavigationPageView {
            navigationPageViewController.pageViewDelegate = self
        }
    }
}

extension MyProfileView: NavigationPageViewControllerDelegate {
    func navigationPageViewController(navigationPageViewController: NavigationPageView,
                                      didUpdatePageCount count: Int) {
        
    }
    
    func navigationPageViewController(navigationPageViewController: NavigationPageView,
                                      didUpdatePageIndex index: Int){
        masterPageIdentificationNum = index
    }
}




