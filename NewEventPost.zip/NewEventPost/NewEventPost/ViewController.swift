//
//  ViewController.swift
//  NewEventPost
//
//  Created by Akash Wadawadigi on 8/23/16.
//  Copyright © 2016 Stanford University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Setting background color
        self.view.backgroundColor = UIColor(red: 248/255, green: 40/255, blue: 54/255, alpha: 0.85)
        
        //To make the button rounded
        postEvent.layer.cornerRadius = 5
        
        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    @IBOutlet weak var eventLocation: UITextField!
    @IBOutlet weak var eventEndTime: UITextField!
    @IBOutlet weak var eventStartTime: UITextField!
    @IBOutlet weak var eventDate: UITextField!
    @IBOutlet weak var eventTitle: UITextField!
    @IBOutlet weak var addText: UIButton!
    @IBOutlet weak var postEvent: UIButton!


}

