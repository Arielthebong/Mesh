//
//  MyNetworkViewController.swift
//  Mesh
//
//  Created by Kevin Kusch on 8/21/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import UIKit

class MyNetworkViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var networkTableView: UITableView!
    @IBOutlet weak var myNetworkLabel: UILabel!
    var networkData = [User]()
    var rowHeights = [User]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        networkTableView.dataSource = self
        networkTableView.delegate = self

        getConnections({ users in
            self.networkData = users
            self.networkTableView.reloadData()
        })
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.networkData.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell:UITableViewCell? = (networkTableView?.dequeueReusableCellWithIdentifier("connectionCell"))! as UITableViewCell
        if (cell != nil)
        {
            cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "connectionCell")
        }
        cell!.textLabel?.text = networkData[indexPath.row].firstName + " " + networkData[indexPath.row].lastName
        
        // May want to change logic for determining affiliation to show
        cell!.detailTextLabel?.text = "Affiliation:"+networkData[indexPath.row].school != "" ? networkData[indexPath.row].school : networkData[indexPath.row].company
        
        return cell!
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
