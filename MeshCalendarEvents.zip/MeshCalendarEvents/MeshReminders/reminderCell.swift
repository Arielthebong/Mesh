//
//  reminderCell.swift
//  MeshReminders
//
//  Created by Akash Wadawadigi on 8/27/16.
//  Copyright © 2016 Stanford University. All rights reserved.
//

import Foundation
import UIKit

class reminderCell: UITableViewCell{
    
    @IBOutlet weak var contactName: UILabel!
    
    @IBOutlet weak var reminderAffiliation: UILabel!
    @IBOutlet weak var reminderDate: UILabel!
    
    @IBOutlet weak var reminderTime: UILabel!
    

    
}


