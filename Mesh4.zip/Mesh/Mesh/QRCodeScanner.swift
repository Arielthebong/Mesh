//
//  QRCodeScanner.swift
//  Mesh
//
//  Created by Daniel Ssemanda on 8/21/16.
//  Copyright © 2016 Mobius. All rights reserved.
//

import AVFoundation
import UIKit

class QRCodeScanner:  UIViewController, AVCaptureMetadataOutputObjectsDelegate{
    
    var objCaptureSession: AVCaptureSession?
    var objCaptureVideoPreviewLayer: AVCaptureVideoPreviewLayer?
    var vwQRCode: UIView?
    var cameraButton = UIButton()
    var cameraBool = false
    var qrMenuBool = false
    var result = ""
    var qrCodeDisplay = UIView()
    
    override func viewDidLoad() {
       super.viewDidLoad()
//    let frame = self.view.frame
    configureVideoCapture()
    addVideoPreviewLayer()
    initializeQRView()
    makeButtons()
    
        
    }
    
    func makeButtons(){
        let frame = self.view.frame
        let goBackToNewsFeed = UIButton(frame: CGRectMake(40, frame.height - 95, 45, 45))
        goBackToNewsFeed.setImage(UIImage(named: "icon camera homebutton"), forState: UIControlState.Normal)
        goBackToNewsFeed.addTarget(self, action: #selector(goBackToMainView), forControlEvents: UIControlEvents.TouchUpInside)
        view.addSubview(goBackToNewsFeed)
        
        cameraButton = UIButton(frame: CGRectMake(ceil(frame.width/2 - 30), frame.height - 160, 70, 70))
        cameraButton.setImage(UIImage(named: "icon camera take pic"), forState: UIControlState.Normal)
        cameraButton.alpha = 0.1
        cameraButton.addTarget(self, action: #selector(cameraButtonTouched), forControlEvents: UIControlEvents.TouchUpInside)
        view.addSubview(cameraButton)
        
        let qrCodeDisplayButton = UIButton(frame: CGRectMake(frame.width - 80, frame.height - 93, 45, 45))
        qrCodeDisplayButton.setImage(UIImage(named: "icon camera switchQR"), forState: UIControlState.Normal)
        qrCodeDisplayButton.addTarget(self, action: #selector(toggleShowingQRCode), forControlEvents: UIControlEvents.TouchUpInside)
        view.addSubview(qrCodeDisplayButton)
    }
    
    func configureVideoCapture(){
        let objCaptureDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        var error: NSError?
        let objCaptureDeviceInput: AnyObject!
        do{
            objCaptureDeviceInput = try AVCaptureDeviceInput(device: objCaptureDevice) as AVCaptureDeviceInput
        } catch let error1 as NSError {
            error = error1
            objCaptureDeviceInput = nil
        }
        if (error != nil) {
            let alertView: UIAlertController = UIAlertController(title: "Device Error", message: "Device not supported for this Application", preferredStyle: .Alert)
            let defaultAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alertView.addAction(defaultAction)
            presentViewController(alertView, animated: true, completion: nil)
            return
        }
        objCaptureSession = AVCaptureSession()
        objCaptureSession?.addInput(objCaptureDeviceInput as! AVCaptureInput)
        let objCaptureMetadataOutput = AVCaptureMetadataOutput()
        objCaptureSession?.addOutput(objCaptureMetadataOutput)
        objCaptureMetadataOutput.setMetadataObjectsDelegate(self, queue: dispatch_get_main_queue())
        objCaptureMetadataOutput.metadataObjectTypes = [AVMetadataObjectTypeQRCode]
    }

    func addVideoPreviewLayer(){
        objCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: objCaptureSession)
        objCaptureVideoPreviewLayer?.videoGravity = AVLayerVideoGravityResizeAspectFill
        objCaptureVideoPreviewLayer?.frame = view.layer.bounds
        self.view.layer.addSublayer(objCaptureVideoPreviewLayer!) //Unwrapped the PreviewLayer
        objCaptureSession?.startRunning()
        
    }
    
    func goBackToMainView() {
        scanner.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func toggleShowingQRCode(){
      let frame = self.view.frame
        if (!qrMenuBool){
            
            qrCodeDisplay = UIView(frame: CGRectMake(floor(frame.width/2) - 125, floor(frame.height/2) - 175, 250, 250))
            qrCodeDisplay.layer.cornerRadius = 10
            qrCodeDisplay.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            qrCodeDisplay.alpha = 0.8
            
            let fakeId = 95896
            let qrImage = generateQRCodeFromIdNum(fakeId)
            let qrView = UIImageView(image: qrImage)
            let colorMask = UIView()
            colorMask.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
            colorMask.alpha = 0.6
            
            qrCodeDisplay.addSubview(qrView)
            qrCodeDisplay.addSubview(colorMask)
            qrCodeDisplay.addConstraintsWithFormat("H:|[v0]|", views: qrView)
            qrCodeDisplay.addConstraintsWithFormat("V:|[v0]|", views: qrView)
            qrCodeDisplay.addConstraintsWithFormat("H:|[v0(250)]|", views: colorMask)
            qrCodeDisplay.addConstraintsWithFormat("V:|[v0(250)]|", views: colorMask)
            view.addSubview(qrCodeDisplay)
            cameraBool = false
            qrMenuBool = true
            cameraButton.alpha = 0.1
        }
        else {
            qrCodeDisplay.removeFromSuperview()
            qrMenuBool = false
        }
        
    }

    func initializeQRView(){
        vwQRCode = UIView()
//        vwQRCode?.layer.borderColor = UIColor.rgb(229, green: 38, blue: 54).CGColor
//        vwQRCode?.layer.borderWidth = 3
        self.view.addSubview(vwQRCode!)
    }
    
    func captureOutput(captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [AnyObject]!, fromConnection connection: AVCaptureConnection!) {
        if metadataObjects == nil || metadataObjects.count == 0{
            vwQRCode?.frame = CGRectZero
            cameraButton.alpha = 0.1
            cameraBool = false
            return
        }
        
    let objMetadataMachineReadableCodeObject = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        if objMetadataMachineReadableCodeObject.type == AVMetadataObjectTypeQRCode{
            let objBarCode = objCaptureVideoPreviewLayer?.transformedMetadataObjectForMetadataObject(objMetadataMachineReadableCodeObject as AVMetadataMachineReadableCodeObject) as! AVMetadataMachineReadableCodeObject
            vwQRCode?.frame = objBarCode.bounds;
            if (objMetadataMachineReadableCodeObject.stringValue != nil) {
//              vwQRCode?.layer.borderColor = UIColor.rgb(229, green: 38, blue: 54).CGColor
             let arrayWithData = breakDownQRCodeString(objMetadataMachineReadableCodeObject.stringValue)
                if isMeshQRCode(arrayWithData) {
                result = getIDNumber(arrayWithData)
                    if (result != ""){
                        if (!qrMenuBool){
                        cameraButton.alpha = 1
                        cameraBool = true
//                        vwQRCode?.layer.borderColor = UIColor.greenColor().CGColor
                        }
                    }
                }
             
//             print("I am reading this: \(arrayWithData[0])")
            }
        }
    }
    
    func isMeshQRCode( qrCodeInfoGiven: [String]) -> Bool{
        if qrCodeInfoGiven[0] == "Start: MeshCard" {
            return true
        }
        else { return false }
    }
    
    func getIDNumber(qrCodeInfoGiven: [String]) -> String{
        if (qrCodeInfoGiven.count > 1) {
           return qrCodeInfoGiven[1]
        }
        else {return ""}
        
    }
    
    func breakDownQRCodeString (qrCodeInfo: String) -> [String]{
        var arrayOfInfo:[String] = []
        qrCodeInfo.enumerateLines{arrayOfInfo.append($0.line)}
        return arrayOfInfo
    }

    func cameraButtonTouched() {
        if (cameraBool) {
//            print("Yo this actually works!!!!")
        let frame = self.view.frame
        let notificationOfAddition = UIView(frame: CGRectMake(0, 0, frame.width, 40))
        notificationOfAddition.backgroundColor = UIColor.rgb(229, green: 38, blue: 54)
        let notificationText = UILabel()
        notificationText.text = "You have added the ID: \(result)"
        notificationText.textColor = UIColor.whiteColor()
        notificationOfAddition.addSubview(notificationText)
        notificationOfAddition.addConstraintsWithFormat("H:|-8-[v0]|", views: notificationText)
        notificationOfAddition.addConstraintsWithFormat("V:[v0(20)]|", views: notificationText)
        
        UIView.animateWithDuration( 0.3, delay: 0.0, options: .CurveEaseIn , animations: {
                    let slideInFromTopTransition = CATransition()
                    slideInFromTopTransition.type = kCATransitionPush
                    slideInFromTopTransition.subtype = kCATransitionFromTop
                    slideInFromTopTransition.duration = 0.3
                    //        slideInFromTopTransition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
                    slideInFromTopTransition.fillMode = kCAFillModeRemoved
                    notificationOfAddition.layer.addAnimation(slideInFromTopTransition, forKey: "slideInFromTopTransition")
            self.view.addSubview(notificationOfAddition)
                    
                }, completion: {finished in
            UIView.animateWithDuration(0.3, delay: 3, options: .CurveEaseIn , animations: {
                    let up = CGAffineTransformMakeTranslation(0, -45)
                    notificationOfAddition.transform = up
                }, completion: {finished in notificationOfAddition.removeFromSuperview() })
                }
            )

        
        }
    }


}

func generateQRCodeFromIdNum(idNum: Int) -> UIImage? {
    
    let string = "Start: MeshCard\n\(idNum)"
    
    let data = string.dataUsingEncoding(NSISOLatin1StringEncoding)
    
    if let filter = CIFilter(name: "CIQRCodeGenerator") {
        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("H", forKey: "inputCorrectionLevel")
        let transform = CGAffineTransformMakeScale(10, 10)
        
        if let output = filter.outputImage?.imageByApplyingTransform(transform) {
            return UIImage(CIImage: output)
        }
    }
    
    return nil
}