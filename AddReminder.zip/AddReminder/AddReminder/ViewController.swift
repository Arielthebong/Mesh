//
//  ViewController.swift
//  AddReminder
//
//  Created by Akash Wadawadigi on 8/27/16.
//  Copyright © 2016 Stanford University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Setting background color
        self.view.backgroundColor = UIColor(red: 248/255, green: 40/255, blue: 54/255, alpha: 0.85)
        
        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    //This outlet is for the intial follow up reminder notification
    @IBOutlet weak var initialFollowUp: UITextField!

    //This outlet is for the reminder that occurs with frequency
    @IBOutlet weak var frequencyOfReminder: UITextField!
    
    //The following three outlets are for the set date
    @IBOutlet weak var monthOfSetDate: UITextField!
    
    @IBOutlet weak var dayOfSetDate: UITextField!
    
    @IBOutlet weak var yearOfSetDate: UITextField!
    
    @IBAction func reminderToggle(sender: AnyObject) {
        if(sender.titleLabel?!.text == "✓"){
            sender.setTitle(" ", forState: .Normal)
        } else if (sender.titleLabel?!.text == " "){
            sender.setTitle("✓", forState: .Normal)
        }
    }
    
    @IBAction func autoReminderToggle(sender: AnyObject) {
        reminderToggle(sender)
    }
    
    
    @IBAction func setDateReminder(sender: AnyObject) {
        reminderToggle(sender)
    }
    
}

